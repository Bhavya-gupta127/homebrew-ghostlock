/* GhostLock v1.0.0 — Proprietary Freeware */
const {
app,
BrowserWindow,
ipcMain,
globalShortcut,
powerSaveBlocker,
screen,
desktopCapturer,
Tray,
Menu,
nativeImage
} = require('electron');
const path = require('path');
const { SecurityManager } = require('./security');
const { SystemMonitor } = require('./system-monitor');
let securityManager;
let systemMonitor;
let mainWindow = null;
let secondaryShieldWindows = [];
let tray = null;
let isLocked = false;
let powerSaveBlockerId = null;
let focusWatchdogTimer = null;
let telemetryTimer = null;
let preLockWindowBounds = { width: 1080, height: 750, x: undefined, y: undefined };
const DASHBOARD_WIDTH = 1080;
const DASHBOARD_HEIGHT = 750;
function createTrayIcon() {
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" fill="#0f172a"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`;
const dataUrl = `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
return nativeImage.createFromDataURL(dataUrl).resize({ width: 18, height: 18 });
}
function setupTray() {
try {
tray = new Tray(createTrayIcon());
tray.setToolTip('GhostLock — Awake Screen Lock for Background LLMs');
updateTrayMenu();
tray.on('click', () => {
if (!mainWindow) return;
if (!isLocked) {
mainWindow.show();
mainWindow.focus();
}
});
} catch (err) {
console.warn('Tray creation skipped:', err.message);
}
}
function updateTrayMenu() {
if (!tray) return;
const cfg = securityManager.getSafeConfig();
const contextMenu = Menu.buildFromTemplate([
{
label: isLocked ? '🔒 Screen Locked (Caffeinate Active)' : '🟢 GhostLock Ready',
enabled: false
},
{ type: 'separator' },
{
label: 'Engage GhostLock Overlay Now',
accelerator: cfg.hotkey || 'CommandOrControl+Shift+L',
enabled: !isLocked,
click: () => triggerLockFromShortcutOrTray()
},
{
label: `Keep Display On: ${cfg.keepDisplayOn ? 'ON' : 'OFF'}`,
type: 'checkbox',
checked: Boolean(cfg.keepDisplayOn),
click: (menuItem) => {
securityManager.saveConfig({ keepDisplayOn: menuItem.checked });
if (isLocked) {
applyPowerSaveBlocker( true, menuItem.checked );
}
updateTrayMenu();
}
},
{ type: 'separator' },
{
label: 'Open Control Center',
enabled: !isLocked,
click: () => {
if (mainWindow) {
mainWindow.show();
mainWindow.focus();
}
}
},
{
label: 'Native OS Lock & Sleep Now',
click: async () => {
if (isLocked) {
await handleEmergencyOsSleep();
} else {
await systemMonitor.triggerNativeOsSleepAndLock();
}
}
},
{ type: 'separator' },
{
label: 'Quit GhostLock',
enabled: !isLocked,
click: () => {
if (!isLocked) {
app.isQuitting = true;
app.quit();
}
}
}
]);
tray.setContextMenu(contextMenu);
}
function applyPowerSaveBlocker(active, keepDisplayOn = true) {
if (powerSaveBlockerId !== null && powerSaveBlocker.isStarted(powerSaveBlockerId)) {
powerSaveBlocker.stop(powerSaveBlockerId);
powerSaveBlockerId = null;
}
systemMonitor.stopNativeCaffeinate();
if (active) {
const mode = keepDisplayOn ? 'prevent-display-sleep' : 'prevent-app-suspension';
powerSaveBlockerId = powerSaveBlocker.start(mode);
systemMonitor.startNativeCaffeinate(keepDisplayOn);
}
}
async function captureDesktopBackdropDataUrl() {
try {
if (mainWindow && !mainWindow.isDestroyed()) {
mainWindow.setOpacity(0);
await new Promise((r) => setTimeout(r, 60));
}
const sources = await desktopCapturer.getSources({
types: ['screen'],
thumbnailSize: { width: 1600, height: 900 }
});
if (mainWindow && !mainWindow.isDestroyed()) {
mainWindow.setOpacity(1);
}
if (sources && sources.length > 0 && sources[0].thumbnail) {
return sources[0].thumbnail.toDataURL();
}
} catch (err) {
if (mainWindow && !mainWindow.isDestroyed()) {
mainWindow.setOpacity(1);
}
console.warn('Desktop backdrop capture fallback:', err.message);
}
return await systemMonitor.captureDesktopScreenDataUrl();
}
function createMainWindow() {
mainWindow = new BrowserWindow({
width: DASHBOARD_WIDTH,
height: DASHBOARD_HEIGHT,
minWidth: 940,
minHeight: 660,
frame: false,
transparent: true,
backgroundColor: '#00000000',
titleBarStyle: 'hidden',
show: false,
webPreferences: {
preload: path.join(__dirname, 'preload.js'),
contextIsolation: true,
nodeIntegration: false,
devTools: !app.isPackaged
}
});
mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
mainWindow.once('ready-to-show', () => {
mainWindow.show();
if (process.argv.includes('--lock-immediately')) {
setTimeout(() => triggerLockFromShortcutOrTray(), 500);
}
});
mainWindow.on('close', (e) => {
if (isLocked) {
e.preventDefault();
recordAndBroadcastTamper('BLOCKED_WINDOW_CLOSE', {
source: 'Window Close Attempt'
});
return false;
}
});
mainWindow.webContents.on('before-input-event', (event, input) => {
if (!isLocked) return;
const key = (input.key || '').toLowerCase();
const isCmdOrCtrl = input.control || input.meta;
const isAlt = input.alt;
const blockedCombinations =
(isAlt && key === 'f4') ||
(isCmdOrCtrl && ['q', 'w', 'h', 'm', 'r', 'tab', 'escape'].includes(key)) ||
(isCmdOrCtrl && input.shift && ['i', 'j', 'c', 'w', 'q'].includes(key)) ||
(isAlt && key === 'tab') ||
['f11', 'f12', 'meta', 'super'].includes(key);
if (blockedCombinations && input.type === 'keyDown') {
event.preventDefault();
const comboName = [
input.meta ? 'Cmd' : '',
input.control ? 'Ctrl' : '',
input.alt ? 'Alt' : '',
input.shift ? 'Shift' : '',
input.key.toUpperCase()
]
.filter(Boolean)
.join('+');
recordAndBroadcastTamper('BLOCKED_SHORTCUT', { shortcut: comboName });
}
});
mainWindow.on('blur', () => {
if (isLocked && mainWindow && !mainWindow.isDestroyed()) {
mainWindow.focus();
mainWindow.moveTop();
}
});
mainWindow.on('leave-full-screen', () => {
if (isLocked && mainWindow && !mainWindow.isDestroyed()) {
mainWindow.setFullScreen(true);
mainWindow.setKiosk(true);
recordAndBroadcastTamper('BLOCKED_FULLSCREEN_EXIT', { source: 'leave-full-screen' });
}
});
mainWindow.on('minimize', (e) => {
if (isLocked && mainWindow && !mainWindow.isDestroyed()) {
e.preventDefault();
mainWindow.restore();
mainWindow.setFullScreen(true);
mainWindow.setKiosk(true);
}
});
}
function spawnSecondaryShieldWindows(theme) {
destroySecondaryShieldWindows();
const cfg = securityManager.getSafeConfig();
if (!cfg.lockAllDisplays) return;
const displays = screen.getAllDisplays();
const primaryDisplay = screen.getPrimaryDisplay();
for (const disp of displays) {
if (disp.id === primaryDisplay.id) continue;
const shield = new BrowserWindow({
x: disp.bounds.x,
y: disp.bounds.y,
width: disp.bounds.width,
height: disp.bounds.height,
frame: false,
fullscreen: true,
kiosk: true,
alwaysOnTop: true,
skipTaskbar: true,
movable: false,
resizable: false,
minimizable: false,
closable: false,
backgroundColor: '#04060a',
webPreferences: {
preload: path.join(__dirname, 'preload.js'),
contextIsolation: true,
nodeIntegration: false
}
});
shield.setAlwaysOnTop(true, 'screen-saver', 1);
shield.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
shield.loadFile(path.join(__dirname, 'renderer', 'index.html'), {
query: { mode: 'secondary-shield', theme: theme || cfg.overlayTheme }
});
shield.on('close', (e) => {
if (isLocked) e.preventDefault();
});
secondaryShieldWindows.push(shield);
}
}
function destroySecondaryShieldWindows() {
for (const win of secondaryShieldWindows) {
if (win && !win.isDestroyed()) {
win.removeAllListeners('close');
win.destroy();
}
}
secondaryShieldWindows = [];
}
function recordAndBroadcastTamper(type, details) {
const evt = securityManager.recordTamperEvent(type, details);
if (mainWindow && !mainWindow.isDestroyed()) {
mainWindow.webContents.send('ghostlock:tamper-recorded', {
event: evt,
totalSessionEvents: securityManager.currentSessionEvents.length,
failedAttempts: securityManager.failedAttempts
});
}
}
async function engageLockOverlay(options = {}) {
if (isLocked || !mainWindow) return { ok: true, alreadyLocked: true };
if (options.configUpdates) {
securityManager.saveConfig(options.configUpdates);
}
if (options.sessionPassword && String(options.sessionPassword).trim().length >= 2) {
securityManager.startLockSession(String(options.sessionPassword).trim());
} else if (securityManager.hasValidPasswordConfigured()) {
securityManager.startLockSession(null);
} else {
return {
ok: false,
error: 'Please set a GhostLock password or enter a Quick Session PIN before locking.'
};
}
const backdropDataUrl = await captureDesktopBackdropDataUrl();
preLockWindowBounds = mainWindow.getBounds();
isLocked = true;
const cfg = securityManager.getSafeConfig();
applyPowerSaveBlocker(true, cfg.keepDisplayOn);
systemMonitor.startOsKeyboardShield((blockedKey) => {
recordAndBroadcastTamper('BLOCKED_SHORTCUT', { shortcut: blockedKey });
});
mainWindow.show();
mainWindow.setAlwaysOnTop(true, 'screen-saver', 1);
mainWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
mainWindow.setFullScreenable(true);
mainWindow.setFullScreen(true);
mainWindow.setKiosk(true);
mainWindow.setClosable(false);
mainWindow.setMinimizable(false);
mainWindow.setMovable(false);
mainWindow.setResizable(false);
mainWindow.focus();
mainWindow.moveTop();
spawnSecondaryShieldWindows(cfg.overlayTheme);
if (focusWatchdogTimer) clearInterval(focusWatchdogTimer);
focusWatchdogTimer = setInterval(() => {
if (!isLocked || !mainWindow || mainWindow.isDestroyed()) return;
if (!mainWindow.isFullScreen()) {
mainWindow.setFullScreen(true);
}
if (!mainWindow.isKiosk()) {
mainWindow.setKiosk(true);
}
if (!mainWindow.isFocused()) {
mainWindow.focus();
mainWindow.moveTop();
}
mainWindow.setAlwaysOnTop(true, 'screen-saver', 1);
checkSafetyAutoSleepGuards();
}, 250);
updateTrayMenu();
const payload = {
isLocked: true,
lockStartedAt: securityManager.lockStartedAt,
config: cfg,
backdropDataUrl,
telemetry: systemMonitor.getTelemetrySnapshot()
};
mainWindow.webContents.send('ghostlock:lock-state-changed', payload);
return { ok: true, ...payload };
}
function disengageLockOverlay(sessionSummary = null) {
isLocked = false;
if (focusWatchdogTimer) {
clearInterval(focusWatchdogTimer);
focusWatchdogTimer = null;
}
systemMonitor.stopOsKeyboardShield();
applyPowerSaveBlocker(false);
destroySecondaryShieldWindows();
if (mainWindow && !mainWindow.isDestroyed()) {
mainWindow.setClosable(true);
mainWindow.setMinimizable(true);
mainWindow.setMovable(true);
mainWindow.setResizable(true);
mainWindow.setKiosk(false);
mainWindow.setFullScreen(false);
mainWindow.setAlwaysOnTop(false);
mainWindow.setVisibleOnAllWorkspaces(false);
if (preLockWindowBounds && preLockWindowBounds.width) {
mainWindow.setBounds(preLockWindowBounds);
} else {
mainWindow.setSize(DASHBOARD_WIDTH, DASHBOARD_HEIGHT);
mainWindow.center();
}
mainWindow.show();
mainWindow.focus();
mainWindow.webContents.send('ghostlock:lock-state-changed', {
isLocked: false,
config: securityManager.getSafeConfig(),
sessionSummary,
tamperLogs: securityManager.getTamperLogs()
});
}
updateTrayMenu();
}
async function handleEmergencyOsSleep(reason = 'EMERGENCY_OS_SLEEP') {
securityManager.recordTamperEvent(reason, {
note: 'Triggered Native OS Lock Screen & Sleep Fallback'
});
const summary = securityManager.finishLockSession(reason);
await systemMonitor.triggerNativeOsSleepAndLock();
disengageLockOverlay(summary);
return { ok: true, summary };
}
function checkSafetyAutoSleepGuards() {
if (!isLocked) return;
const cfg = securityManager.config;
const telemetry = systemMonitor.cachedBattery;
if (
cfg.lowBatteryGuardEnabled &&
telemetry &&
telemetry.hasBattery &&
!telemetry.isCharging &&
telemetry.percent <= (cfg.lowBatteryThreshold || 15)
) {
handleEmergencyOsSleep('LOW_BATTERY_AUTO_SLEEP');
return;
}
if (cfg.autoSleepAfterMinutes && cfg.autoSleepAfterMinutes > 0 && securityManager.lockStartedAt) {
const elapsedMinutes = (Date.now() - securityManager.lockStartedAt) / 60000;
if (elapsedMinutes >= cfg.autoSleepAfterMinutes) {
handleEmergencyOsSleep('MAX_AWAY_TIMER_AUTO_SLEEP');
}
}
}
function triggerLockFromShortcutOrTray() {
if (isLocked) return;
if (!securityManager.hasValidPasswordConfigured()) {
if (mainWindow) {
mainWindow.show();
mainWindow.focus();
mainWindow.webContents.send('ghostlock:prompt-setup-password');
}
return;
}
engageLockOverlay({});
}
function registerGlobalHotkeys() {
globalShortcut.unregisterAll();
const cfg = securityManager.getSafeConfig();
const shortcuts = [cfg.hotkey || 'CommandOrControl+Shift+L', cfg.secondaryHotkey || 'CommandOrControl+Alt+L'];
for (const accel of shortcuts) {
if (!accel) continue;
try {
globalShortcut.register(accel, () => {
triggerLockFromShortcutOrTray();
});
} catch (err) {
console.warn(`Failed to register shortcut ${accel}:`, err.message);
}
}
}
function setupIpcHandlers() {
ipcMain.handle('ghostlock:get-initial-state', () => {
return {
isLocked,
lockStartedAt: securityManager.lockStartedAt,
config: securityManager.getSafeConfig(),
telemetry: systemMonitor.getTelemetrySnapshot(),
tamperLogs: securityManager.getTamperLogs()
};
});
ipcMain.handle('ghostlock:save-config', (_event, partialConfig) => {
const updated = securityManager.saveConfig(partialConfig);
registerGlobalHotkeys();
if (isLocked) {
applyPowerSaveBlocker(true, updated.keepDisplayOn);
}
updateTrayMenu();
return { ok: true, config: updated };
});
ipcMain.handle('ghostlock:set-master-password', (_event, { password, hint }) => {
try {
securityManager.setMasterPassword(password, hint);
return { ok: true, config: securityManager.getSafeConfig() };
} catch (err) {
return { ok: false, error: err.message };
}
});
ipcMain.handle('ghostlock:engage-lock', async (_event, options) => {
return await engageLockOverlay(options || {});
});
ipcMain.handle('ghostlock:attempt-unlock', (_event, candidatePassword) => {
const result = securityManager.verifyPassword(candidatePassword);
if (result.valid) {
disengageLockOverlay(result.sessionSummary);
} else if (mainWindow && !mainWindow.isDestroyed()) {
mainWindow.webContents.send('ghostlock:tamper-recorded', {
failedAttempts: result.failedAttempts,
totalSessionEvents: securityManager.currentSessionEvents.length
});
}
return result;
});
ipcMain.handle('ghostlock:emergency-os-sleep', async () => {
return await handleEmergencyOsSleep('EMERGENCY_OS_SLEEP');
});
ipcMain.handle('ghostlock:get-telemetry', () => {
return systemMonitor.getTelemetrySnapshot();
});
ipcMain.handle('ghostlock:get-tamper-logs', () => {
return securityManager.getTamperLogs();
});
ipcMain.handle('ghostlock:clear-tamper-logs', () => {
securityManager.clearTamperLogs();
return { ok: true };
});
ipcMain.handle('ghostlock:record-tamper', (_event, { type, details }) => {
recordAndBroadcastTamper(type, details);
return { ok: true };
});
ipcMain.handle('ghostlock:window-minimize', () => {
if (!isLocked && mainWindow) mainWindow.minimize();
});
ipcMain.handle('ghostlock:window-close', () => {
if (!isLocked && mainWindow) mainWindow.close();
});
}
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
app.quit();
} else {
app.on('second-instance', () => {
if (mainWindow) {
if (mainWindow.isMinimized()) mainWindow.restore();
mainWindow.show();
mainWindow.focus();
}
});
app.whenReady().then(() => {
const { session } = require('electron');
if (session && session.defaultSession) {
session.defaultSession.setPermissionCheckHandler((_webContents, permission) => {
if (permission === 'media') return true;
return false;
});
session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
if (permission === 'media') return callback(true);
callback(false);
});
}
securityManager = new SecurityManager(app.getPath('userData'));
systemMonitor = new SystemMonitor();
setupIpcHandlers();
createMainWindow();
setupTray();
registerGlobalHotkeys();
screen.on('display-added', () => {
if (isLocked) {
recordAndBroadcastTamper('DISPLAY_TOPOLOGY_CHANGED', { action: 'display-added' });
spawnSecondaryShieldWindows(securityManager.config.overlayTheme);
}
});
screen.on('display-removed', () => {
if (isLocked) {
recordAndBroadcastTamper('DISPLAY_TOPOLOGY_CHANGED', { action: 'display-removed' });
spawnSecondaryShieldWindows(securityManager.config.overlayTheme);
}
});
telemetryTimer = setInterval(() => {
if (mainWindow && !mainWindow.isDestroyed()) {
mainWindow.webContents.send(
'ghostlock:telemetry-update',
systemMonitor.getTelemetrySnapshot()
);
}
}, 2000);
});
}
app.on('will-quit', (e) => {
if (isLocked) {
e.preventDefault();
return;
}
globalShortcut.unregisterAll();
applyPowerSaveBlocker(false);
if (telemetryTimer) clearInterval(telemetryTimer);
});
