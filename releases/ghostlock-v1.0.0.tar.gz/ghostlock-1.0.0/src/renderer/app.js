/* GhostLock v1.0.0 — Proprietary Freeware */
(function () {
const isElectron = Boolean(window.ghostlockAPI);
let browserWakeLock = null;
const bridge = isElectron
? window.ghostlockAPI
: {
async getInitialState() {
const r = await fetch('/api/initial-state');
return r.json();
},
async saveConfig(partial) {
const r = await fetch('/api/save-config', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify(partial)
});
return r.json();
},
async setMasterPassword(password, hint) {
const r = await fetch('/api/set-master-password', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ password, hint })
});
return r.json();
},
async engageLock(options) {
const r = await fetch('/api/engage-lock', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify(options || {})
});
return r.json();
},
async attemptUnlock(password) {
const r = await fetch('/api/attempt-unlock', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ password })
});
return r.json();
},
async triggerEmergencyOsSleep() {
const r = await fetch('/api/emergency-os-sleep', { method: 'POST' });
return r.json();
},
async getTelemetry() {
const r = await fetch('/api/telemetry');
return r.json();
},
async getTamperLogs() {
const r = await fetch('/api/tamper-logs');
return r.json();
},
async clearTamperLogs() {
const r = await fetch('/api/clear-tamper-logs', { method: 'POST' });
return r.json();
},
async recordTamperEvent(type, details) {
const r = await fetch('/api/record-tamper', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ type, details })
});
return r.json();
},
minimizeWindow() {},
closeWindow() {
window.close();
},
onLockStateChanged() {},
onTelemetryUpdate() {},
onTamperRecorded() {}
};
let appState = {
isLocked: false,
lockStartedAt: null,
config: {
overlayTheme: 'liquid-glass',
glassBlurPx: 14,
screenBrightnessDim: 0,
keepDisplayOn: true,
showHeartbeatWidget: true,
lockAllDisplays: true,
lowBatteryGuardEnabled: true,
captureWebcamOnTamper: true,
autoSleepAfterMinutes: 0,
awayCustomMessage: 'Background LLM / Agent Running — Please Do Not Disturb',
awayReturnMinutes: 45,
hotkey: 'CommandOrControl+Shift+L',
passwordHint: '',
hasPasswordSet: false
},
backdropDataUrl: null,
telemetry: {
cpuPercent: 14,
cpuHistory: [12, 15, 18, 14, 22, 19, 16, 14],
memPercent: 48,
usedMemGb: '7.6',
totalMemGb: '16',
battery: { percent: 100, isCharging: true, source: 'AC Power' },
activeWorkloads: []
},
tamperLogs: {
currentSessionEvents: [],
historicalLogs: [],
failedAttempts: 0
}
};
let awayClockInterval = null;
let decoyStreamInterval = null;
const urlParams = new URLSearchParams(window.location.search);
const isSecondaryShield = urlParams.get('mode') === 'secondary-shield';
if (isSecondaryShield) {
const shieldTheme = urlParams.get('theme') || 'liquid-glass';
document.body.className = `theme-${shieldTheme}`;
document.getElementById('dashboard-view').classList.add('hidden');
document.getElementById('secondary-shield-view').classList.remove('hidden');
return;
}
const elDashboardView = document.getElementById('dashboard-view');
const elLockOverlayView = document.getElementById('lock-overlay-view');
const elSoftwareDimmer = document.getElementById('software-dimmer');
const elDesktopBackdrop = document.getElementById('desktop-backdrop-layer');
const elDesktopUnderlay = document.getElementById('desktop-underlay-workspace');
const elDecoyUpdateLayer = document.getElementById('decoy-update-layer');
const elDecoyWinUpdateLayer = document.getElementById('decoy-win-update-layer');
const elDecoyTerminalLayer = document.getElementById('decoy-terminal-layer');
const elDecoyTerminalOutput = document.getElementById('decoy-terminal-output');
const elDecoyBlindHint = document.getElementById('decoy-blind-unlock-hint');
async function init() {
try {
const initial = await bridge.getInitialState();
if (initial) {
appState = { ...appState, ...initial };
}
} catch (err) {
console.warn('Initial state fetch warning:', err);
}
bindDashboardEvents();
bindLockOverlayEvents();
syncConfigToUI();
renderTelemetry(appState.telemetry);
renderTamperLogs(appState.tamperLogs);
if (appState.isLocked) {
enterLockUI(appState);
}
if (isElectron) {
bridge.onLockStateChanged((payload) => {
if (payload.config) appState.config = payload.config;
if (payload.isLocked) {
appState.isLocked = true;
appState.lockStartedAt = payload.lockStartedAt || Date.now();
enterLockUI(payload);
} else {
appState.isLocked = false;
exitLockUI(payload);
}
});
bridge.onTelemetryUpdate((telemetry) => {
appState.telemetry = telemetry;
renderTelemetry(telemetry);
});
bridge.onTamperRecorded((info) => {
updateLockTamperBadge(info.totalSessionEvents || info.failedAttempts || 1);
bridge.getTamperLogs().then((logs) => {
appState.tamperLogs = logs;
renderTamperLogs(logs);
});
});
} else {
setInterval(async () => {
try {
const t = await bridge.getTelemetry();
appState.telemetry = t;
renderTelemetry(t);
} catch (_) {}
}, 2500);
}
}
function formatHotkeyDisplay(accel) {
const isMac = navigator.platform.toUpperCase().includes('MAC');
return String(accel || 'CommandOrControl+Shift+L')
.replace('CommandOrControl', isMac ? '⌘' : 'Ctrl')
.replace('Shift', isMac ? '⇧' : 'Shift')
.replace('Alt', isMac ? '⌥' : 'Alt')
.replace(/\+/g, ' + ');
}
function syncConfigToUI() {
const cfg = appState.config;
document.body.className = `theme-${cfg.overlayTheme || 'liquid-glass'}`;
document.documentElement.style.setProperty('--glass-blur', `${cfg.glassBlurPx || 14}px`);
const dimRatio = appState.isLocked ? (Number(cfg.screenBrightnessDim) || 0) / 100 : 0;
elSoftwareDimmer.style.opacity = String(dimRatio);
const prettyKey = formatHotkeyDisplay(cfg.hotkey);
document.getElementById('hotkey-display').textContent = prettyKey;
document.getElementById('btn-hotkey-label').textContent = prettyKey.replace(/\s+/g, '');
const elPassPill = document.getElementById('password-status-pill');
if (cfg.hasPasswordSet) {
elPassPill.textContent = '✓ Master Password Configured';
elPassPill.classList.add('ready');
} else {
elPassPill.textContent = 'No Master Password (Use Quick Session PIN or Set Master)';
elPassPill.classList.remove('ready');
}
document.querySelectorAll('.theme-option-card').forEach((card) => {
card.classList.toggle('selected', card.dataset.theme === cfg.overlayTheme);
});
const isDecoyTheme =
cfg.overlayTheme === 'decoy-update' ||
cfg.overlayTheme === 'decoy-win-update' ||
cfg.overlayTheme === 'decoy-terminal';
if (elDecoyBlindHint) {
elDecoyBlindHint.classList.toggle('hidden', !isDecoyTheme);
}
const blurSlider = document.getElementById('slider-glass-blur');
const dimSlider = document.getElementById('slider-screen-dim');
if (blurSlider) {
blurSlider.value = cfg.glassBlurPx || 14;
document.getElementById('val-glass-blur').textContent = `${cfg.glassBlurPx || 14} px`;
}
if (dimSlider) {
dimSlider.value = cfg.screenBrightnessDim || 0;
document.getElementById('val-screen-dim').textContent = `${cfg.screenBrightnessDim || 0}%`;
}
document.getElementById('input-away-message').value =
cfg.awayCustomMessage || 'Background LLM / Agent Running — Please Do Not Disturb';
document.getElementById('select-return-mins').value = String(cfg.awayReturnMinutes ?? 45);
document.getElementById('chk-keep-display-on').checked = Boolean(cfg.keepDisplayOn);
document.getElementById('chk-show-heartbeat').checked = Boolean(cfg.showHeartbeatWidget);
document.getElementById('chk-lock-all-displays').checked = Boolean(cfg.lockAllDisplays);
document.getElementById('chk-low-battery-guard').checked = Boolean(cfg.lowBatteryGuardEnabled);
const chkWebcam = document.getElementById('chk-capture-webcam');
if (chkWebcam) chkWebcam.checked = cfg.captureWebcamOnTamper !== false;
document.getElementById('select-auto-sleep').value = String(cfg.autoSleepAfterMinutes || 0);
document.getElementById('select-hotkey').value = cfg.hotkey || 'CommandOrControl+Shift+L';
document.getElementById('input-master-hint').value = cfg.passwordHint || '';
elDecoyUpdateLayer.classList.toggle('hidden', cfg.overlayTheme !== 'decoy-update');
if (elDecoyWinUpdateLayer) {
elDecoyWinUpdateLayer.classList.toggle('hidden', cfg.overlayTheme !== 'decoy-win-update');
}
elDecoyTerminalLayer.classList.toggle('hidden', cfg.overlayTheme !== 'decoy-terminal');
}
function bindDashboardEvents() {
document.getElementById('btn-win-close').addEventListener('click', () => bridge.closeWindow());
document.getElementById('btn-win-min').addEventListener('click', () => bridge.minimizeWindow());
document.getElementById('btn-win-quicklock').addEventListener('click', () => handleEngageLock());
document.querySelectorAll('.nav-item').forEach((btn) => {
btn.addEventListener('click', () => {
document.querySelectorAll('.nav-item').forEach((b) => b.classList.remove('active'));
document.querySelectorAll('.tab-section').forEach((s) => s.classList.remove('active'));
btn.classList.add('active');
const target = document.getElementById(btn.dataset.tab);
if (target) target.classList.add('active');
});
});
document.querySelectorAll('.theme-option-card').forEach((card) => {
card.addEventListener('click', async () => {
const overlayTheme = card.dataset.theme;
appState.config.overlayTheme = overlayTheme;
syncConfigToUI();
await bridge.saveConfig({ overlayTheme });
});
});
document.getElementById('slider-glass-blur').addEventListener('input', (e) => {
const glassBlurPx = Number(e.target.value);
appState.config.glassBlurPx = glassBlurPx;
document.getElementById('val-glass-blur').textContent = `${glassBlurPx} px`;
document.documentElement.style.setProperty('--glass-blur', `${glassBlurPx}px`);
});
document.getElementById('slider-glass-blur').addEventListener('change', async (e) => {
await bridge.saveConfig({ glassBlurPx: Number(e.target.value) });
});
document.getElementById('slider-screen-dim').addEventListener('input', (e) => {
const screenBrightnessDim = Number(e.target.value);
appState.config.screenBrightnessDim = screenBrightnessDim;
document.getElementById('val-screen-dim').textContent = `${screenBrightnessDim}%`;
});
document.getElementById('slider-screen-dim').addEventListener('change', async (e) => {
await bridge.saveConfig({ screenBrightnessDim: Number(e.target.value) });
});
document.querySelectorAll('.preset-chip').forEach((chip) => {
chip.addEventListener('click', async () => {
document.querySelectorAll('.preset-chip').forEach((c) => c.classList.remove('active'));
chip.classList.add('active');
const msg = chip.dataset.msg;
document.getElementById('input-away-message').value = msg;
appState.config.awayCustomMessage = msg;
appState.config.awayStatusPreset = chip.dataset.preset;
await bridge.saveConfig({
awayCustomMessage: msg,
awayStatusPreset: chip.dataset.preset
});
});
});
document.getElementById('input-away-message').addEventListener('change', async (e) => {
const awayCustomMessage = e.target.value.trim() || 'Background LLM Running — Do Not Disturb';
appState.config.awayCustomMessage = awayCustomMessage;
await bridge.saveConfig({ awayCustomMessage });
});
document.getElementById('select-return-mins').addEventListener('change', async (e) => {
const awayReturnMinutes = Number(e.target.value);
appState.config.awayReturnMinutes = awayReturnMinutes;
await bridge.saveConfig({ awayReturnMinutes });
});
const bindToggle = (id, key) => {
const el = document.getElementById(id);
if (!el) return;
el.addEventListener('change', async (e) => {
appState.config[key] = e.target.checked;
await bridge.saveConfig({ [key]: e.target.checked });
});
};
bindToggle('chk-keep-display-on', 'keepDisplayOn');
bindToggle('chk-show-heartbeat', 'showHeartbeatWidget');
bindToggle('chk-lock-all-displays', 'lockAllDisplays');
bindToggle('chk-low-battery-guard', 'lowBatteryGuardEnabled');
bindToggle('chk-capture-webcam', 'captureWebcamOnTamper');
document.getElementById('select-auto-sleep').addEventListener('change', async (e) => {
const autoSleepAfterMinutes = Number(e.target.value);
appState.config.autoSleepAfterMinutes = autoSleepAfterMinutes;
await bridge.saveConfig({ autoSleepAfterMinutes });
});
document.getElementById('select-hotkey').addEventListener('change', async (e) => {
const hotkey = e.target.value;
appState.config.hotkey = hotkey;
syncConfigToUI();
await bridge.saveConfig({ hotkey });
});
document.getElementById('btn-save-master-pass').addEventListener('click', async () => {
const passInput = document.getElementById('input-master-pass');
const hintInput = document.getElementById('input-master-hint');
const feedbackEl = document.getElementById('master-pass-feedback');
const password = passInput.value.trim();
const hint = hintInput.value.trim();
if (password.length < 2) {
feedbackEl.textContent = '⚠️ Password or PIN must be at least 2 characters.';
feedbackEl.style.color = '#fda4af';
feedbackEl.classList.remove('hidden');
return;
}
const res = await bridge.setMasterPassword(password, hint);
if (res.ok) {
passInput.value = '';
appState.config = res.config;
syncConfigToUI();
feedbackEl.textContent = '✓ Master password saved & hashed with PBKDF2-SHA512.';
feedbackEl.style.color = '#6ee7b7';
feedbackEl.classList.remove('hidden');
} else {
feedbackEl.textContent = `⚠️ ${res.error || 'Failed to save password'}`;
feedbackEl.style.color = '#fda4af';
feedbackEl.classList.remove('hidden');
}
});
document.getElementById('btn-clear-tamper').addEventListener('click', async () => {
await bridge.clearTamperLogs();
appState.tamperLogs = { currentSessionEvents: [], historicalLogs: [], failedAttempts: 0 };
renderTamperLogs(appState.tamperLogs);
});
document.getElementById('btn-view-tamper-from-banner').addEventListener('click', () => {
document.getElementById('post-session-banner').classList.add('hidden');
document.querySelector('[data-tab="tab-security"]').click();
});
document.getElementById('btn-dismiss-banner').addEventListener('click', () => {
document.getElementById('post-session-banner').classList.add('hidden');
});
document.getElementById('btn-engage-lock').addEventListener('click', () => handleEngageLock());
document.getElementById('quick-session-password').addEventListener('keydown', (e) => {
if (e.key === 'Enter') {
e.preventDefault();
handleEngageLock();
}
});
window.addEventListener('keydown', (e) => {
const isCmdOrCtrl = e.metaKey || e.ctrlKey;
if (!appState.isLocked && isCmdOrCtrl && e.shiftKey && e.key.toLowerCase() === 'l') {
e.preventDefault();
handleEngageLock();
}
});
}
async function handleEngageLock() {
const sessionPassEl = document.getElementById('quick-session-password');
const errEl = document.getElementById('lock-error-msg');
const sessionPassword = sessionPassEl.value.trim();
if (!sessionPassword && !appState.config.hasPasswordSet) {
errEl.textContent =
'⚠️ Please enter an Unlock Password / PIN in the box above to lock your screen.';
errEl.classList.remove('hidden');
sessionPassEl.focus();
return;
}
if (sessionPassword && !appState.config.hasPasswordSet && sessionPassword.length >= 2) {
try {
const saveRes = await bridge.setMasterPassword(sessionPassword, appState.config.passwordHint || '');
if (saveRes && saveRes.ok && saveRes.config) {
appState.config = saveRes.config;
syncConfigToUI();
}
} catch (_) {}
}
errEl.classList.add('hidden');
const res = await bridge.engageLock({ sessionPassword });
if (!res.ok) {
errEl.textContent = `⚠️ ${res.error}`;
errEl.classList.remove('hidden');
return;
}
sessionPassEl.value = '';
if (!isElectron) {
await engageKioskInputShield();
enterLockUI(res);
}
}
async function engageKioskInputShield() {
if (isElectron) return;
try {
if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
await document.documentElement.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
}
if (!document.pointerLockElement && document.body.requestPointerLock) {
try {
await document.body.requestPointerLock();
} catch (_) {}
}
if (navigator.keyboard && navigator.keyboard.lock) {
await navigator.keyboard
.lock([
'Escape',
'Tab',
'MetaLeft',
'MetaRight',
'AltLeft',
'AltRight',
'ControlLeft',
'KeyQ',
'KeyW',
'KeyH',
'KeyM',
'F11'
])
.catch(() => {});
}
if (navigator.wakeLock && appState.config.keepDisplayOn && !browserWakeLock) {
browserWakeLock = await navigator.wakeLock.request('screen').catch(() => null);
}
} catch (_) {}
}
async function captureIntruderPhotoZeroPermission(attemptNumber) {
if (appState.config.captureWebcamOnTamper === false) return null;
if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return null;
let permissionGranted = isElectron || urlParams.get('kiosk') === '1';
if (!permissionGranted && navigator.permissions && navigator.permissions.query) {
try {
const permStatus = await navigator.permissions.query({ name: 'camera' });
permissionGranted = Boolean(permStatus && permStatus.state === 'granted');
} catch (_) {
permissionGranted = false;
}
}
if (!permissionGranted) {
return null;
}
let stream = null;
let video = null;
try {
const canvas = document.createElement('canvas');
canvas.width = 320;
canvas.height = 240;
const ctx = canvas.getContext('2d');
const grad = ctx.createLinearGradient(0, 0, 320, 240);
grad.addColorStop(0, '#0f172a');
grad.addColorStop(1, '#1e1b4b');
ctx.fillStyle = grad;
ctx.fillRect(0, 0, canvas.width, canvas.height);
let drewCameraFrame = false;
try {
const mediaPromise = navigator.mediaDevices.getUserMedia({
video: { width: { ideal: 320 }, height: { ideal: 240 } },
audio: false
});
const timeoutPromise = new Promise((_, rej) =>
setTimeout(() => rej(new Error('Camera timeout')), 650)
);
stream = await Promise.race([mediaPromise, timeoutPromise]);
video = document.createElement('video');
video.setAttribute('muted', '');
video.setAttribute('playsinline', '');
video.muted = true;
video.playsInline = true;
video.style.cssText =
'position:fixed;top:-9999px;left:-9999px;width:320px;height:240px;opacity:0;pointer-events:none;z-index:-1;';
document.body.appendChild(video);
video.srcObject = stream;
await Promise.race([
video.play().catch(() => {}),
new Promise((r) => setTimeout(r, 250))
]);
await new Promise((r) => setTimeout(r, 120));
ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
drewCameraFrame = true;
} catch (_) {
ctx.fillStyle = 'rgba(244, 63, 94, 0.16)';
ctx.beginPath();
ctx.arc(160, 92, 34, 0, Math.PI * 2);
ctx.fill();
ctx.beginPath();
ctx.arc(160, 178, 58, Math.PI, Math.PI * 2);
ctx.fill();
}
ctx.fillStyle = 'rgba(10, 14, 24, 0.84)';
ctx.fillRect(0, canvas.height - 26, canvas.width, 26);
ctx.fillStyle = '#fda4af';
ctx.font = 'bold 10.5px monospace';
ctx.fillText(
`INTRUDER #${attemptNumber} • ${new Date().toLocaleTimeString()} ${drewCameraFrame ? '[CAM]' : '[SENSOR]'}`,
8,
canvas.height - 9
);
const photoDataUrl = canvas.toDataURL('image/jpeg', 0.78);
await bridge.recordTamperEvent('INTRUDER_PHOTO', {
attemptNumber,
photoDataUrl
});
return photoDataUrl;
} catch (_) {
return null;
} finally {
if (stream) {
try {
stream.getTracks().forEach((track) => track.stop());
} catch (_) {}
}
if (video && video.parentNode) {
try {
video.parentNode.removeChild(video);
} catch (_) {}
}
}
}
let virtualCursorEl = null;
let virtualX = window.innerWidth / 2;
let virtualY = window.innerHeight / 2;
function ensureVirtualCursor() {
if (!virtualCursorEl) {
virtualCursorEl = document.createElement('div');
virtualCursorEl.id = 'virtual-lock-cursor';
virtualCursorEl.className = 'virtual-lock-cursor hidden';
virtualCursorEl.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 2L20 11L12.5 13.5L9.5 21L4 2Z" fill="#ffffff" stroke="#0f172a" stroke-width="2" stroke-linejoin="round"/></svg>`;
document.body.appendChild(virtualCursorEl);
}
return virtualCursorEl;
}
function releaseKioskInputShield() {
if (isElectron) return;
try {
if (document.pointerLockElement && document.exitPointerLock) {
document.exitPointerLock();
}
if (navigator.keyboard && navigator.keyboard.unlock) {
navigator.keyboard.unlock();
}
if (document.fullscreenElement && document.exitFullscreen) {
document.exitFullscreen().catch(() => {});
}
if (browserWakeLock) {
browserWakeLock.release().catch(() => {});
browserWakeLock = null;
}
if (virtualCursorEl) {
virtualCursorEl.classList.add('hidden');
}
} catch (_) {}
}
function bindLockOverlayEvents() {
const unlockForm = document.getElementById('lock-unlock-form');
const passInput = document.getElementById('lock-password-input');
const passBox = document.getElementById('password-input-box');
const errFeedback = document.getElementById('lock-error-feedback');
ensureVirtualCursor();
unlockForm.addEventListener('submit', async (e) => {
e.preventDefault();
const candidate = passInput.value;
if (!candidate) return;
const result = await bridge.attemptUnlock(candidate);
if (result.valid) {
passInput.value = '';
errFeedback.textContent = '';
if (!isElectron) {
releaseKioskInputShield();
exitLockUI({ sessionSummary: result.sessionSummary });
}
} else {
passInput.value = '';
errFeedback.textContent = result.message || 'Incorrect password.';
passBox.classList.remove('shake');
void passBox.offsetWidth; // Reflow to restart animation
passBox.classList.add('shake');
const attempts = result.failedAttempts || 1;
updateLockTamperBadge(attempts);
passInput.focus();
captureIntruderPhotoZeroPermission(attempts).catch(() => {});
}
});
document.getElementById('btn-toggle-pass-vis').addEventListener('click', () => {
passInput.type = passInput.type === 'password' ? 'text' : 'password';
passInput.focus();
});
const sleepDrawer = document.getElementById('sleep-confirm-drawer');
document.getElementById('btn-forgot-sleep').addEventListener('click', () => {
sleepDrawer.classList.toggle('hidden');
});
document.getElementById('btn-cancel-sleep').addEventListener('click', () => {
sleepDrawer.classList.add('hidden');
passInput.focus();
});
document.getElementById('btn-confirm-os-sleep').addEventListener('click', async () => {
sleepDrawer.classList.add('hidden');
const res = await bridge.triggerEmergencyOsSleep();
if (!isElectron && res.ok) {
releaseKioskInputShield();
exitLockUI({ sessionSummary: res.summary });
}
});
window.addEventListener('mousemove', (e) => {
if (!appState.isLocked) return;
if (document.pointerLockElement) {
virtualX = Math.max(16, Math.min(window.innerWidth - 16, virtualX + (e.movementX || 0)));
virtualY = Math.max(48, Math.min(window.innerHeight - 16, virtualY + (e.movementY || 0)));
if (virtualCursorEl) {
virtualCursorEl.classList.remove('hidden');
virtualCursorEl.style.left = `${virtualX}px`;
virtualCursorEl.style.top = `${virtualY}px`;
}
}
});
document.addEventListener('pointerlockchange', () => {
if (!virtualCursorEl) return;
if (appState.isLocked && document.pointerLockElement) {
virtualCursorEl.classList.remove('hidden');
} else {
virtualCursorEl.classList.add('hidden');
}
});
window.addEventListener('mousedown', (e) => {
if (!appState.isLocked) return;
if (!isElectron && (!document.fullscreenElement || !document.pointerLockElement)) {
engageKioskInputShield();
}
if (document.pointerLockElement) {
const targetEl = document.elementFromPoint(virtualX, virtualY);
if (targetEl) {
const clickable = targetEl.closest('button, input, a, [role="button"]') || targetEl;
if (clickable && typeof clickable.click === 'function' && clickable !== document.body) {
e.preventDefault();
clickable.click();
}
}
}
});
window.addEventListener('keydown', (e) => {
if (!appState.isLocked) return;
if (!isElectron && (!document.fullscreenElement || !document.pointerLockElement)) {
engageKioskInputShield();
}
if (
e.key === 'Escape' ||
e.key === 'F11' ||
((e.metaKey || e.ctrlKey) && ['q', 'w', 'h', 'm', 'tab'].includes(e.key.toLowerCase()))
) {
e.preventDefault();
e.stopPropagation();
bridge.recordTamperEvent('BLOCKED_SHORTCUT', {
shortcut: `${e.metaKey ? 'CMD+' : e.ctrlKey ? 'CTRL+' : ''}${e.key.toUpperCase()}`
});
return;
}
const isDecoy =
appState.config.overlayTheme === 'decoy-update' ||
appState.config.overlayTheme === 'decoy-win-update' ||
appState.config.overlayTheme === 'decoy-terminal';
if (isDecoy || document.pointerLockElement || document.activeElement !== passInput) {
if (!isDecoy && !document.pointerLockElement) {
passInput.focus();
}
if (e.key === 'Enter') {
e.preventDefault();
unlockForm.dispatchEvent(new Event('submit', { cancelable: true }));
} else if (e.key === 'Backspace') {
e.preventDefault();
passInput.value = passInput.value.slice(0, -1);
} else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
e.preventDefault();
passInput.value += e.key;
}
}
});
window.addEventListener('click', () => {
if (!appState.isLocked) return;
if (!isElectron && (!document.fullscreenElement || !document.pointerLockElement)) {
engageKioskInputShield();
}
if (document.activeElement !== passInput) {
passInput.focus();
}
});
document.addEventListener('fullscreenchange', () => {
if (appState.isLocked && !isElectron && !document.fullscreenElement) {
bridge.recordTamperEvent('BLOCKED_SHORTCUT', { shortcut: 'FULLSCREEN_EXIT_ATTEMPT' });
updateLockTamperBadge(1);
}
});
window.addEventListener('beforeunload', (e) => {
if (appState.isLocked) {
bridge.recordTamperEvent('BLOCKED_SHORTCUT', { shortcut: 'WINDOW_CLOSE_ATTEMPT' });
e.preventDefault();
e.returnValue = '';
return '';
}
});
window.addEventListener('contextmenu', (e) => {
if (appState.isLocked) {
e.preventDefault();
}
});
}
function enterLockUI(payload) {
appState.isLocked = true;
appState.lockStartedAt = payload.lockStartedAt || Date.now();
if (payload.config) appState.config = payload.config;
virtualX = Math.round(window.innerWidth / 2);
virtualY = Math.round(window.innerHeight / 2);
const backdropUrl = payload.backdropDataUrl || appState.backdropDataUrl;
if (backdropUrl) {
appState.backdropDataUrl = backdropUrl;
elDesktopBackdrop.style.backgroundImage = `url("${backdropUrl}")`;
} else {
elDesktopBackdrop.style.backgroundImage = 'none';
}
if (elDesktopUnderlay) {
elDesktopUnderlay.classList.remove('hidden');
}
syncConfigToUI();
const cfg = appState.config;
document.getElementById('lock-away-text').textContent =
cfg.awayCustomMessage || 'Background LLM / Agent Running — Please Do Not Disturb';
const returnEl = document.getElementById('lock-return-timer');
if (cfg.awayReturnMinutes && cfg.awayReturnMinutes > 0) {
returnEl.textContent = `Est. Return: ~${cfg.awayReturnMinutes}m`;
returnEl.classList.remove('hidden');
} else {
returnEl.classList.add('hidden');
}
document.getElementById('lock-caffeinate-status').textContent = cfg.keepDisplayOn
? 'CAFFEINATED • SCREEN & BACKGROUND LLM AWAKE'
: 'CAFFEINATED • BACKGROUND LLM AWAKE (DISPLAY SAVER)';
document
.getElementById('lock-heartbeat-widget')
.classList.toggle('hidden', !cfg.showHeartbeatWidget);
const hintEl = document.getElementById('lock-hint-display');
hintEl.textContent = cfg.passwordHint ? `Hint: ${cfg.passwordHint}` : '';
document.getElementById('lock-error-feedback').textContent = '';
document.getElementById('lock-tamper-warning').classList.add('hidden');
document.getElementById('sleep-confirm-drawer').classList.add('hidden');
elDashboardView.classList.add('hidden');
elLockOverlayView.classList.remove('hidden');
const passInput = document.getElementById('lock-password-input');
passInput.value = '';
setTimeout(() => passInput.focus(), 60);
startLockTimers();
startOrStopDecoyAnimations();
}
function exitLockUI(payload = {}) {
appState.isLocked = false;
stopLockTimers();
startOrStopDecoyAnimations();
if (virtualCursorEl) {
virtualCursorEl.classList.add('hidden');
}
elLockOverlayView.classList.add('hidden');
elDashboardView.classList.remove('hidden');
elSoftwareDimmer.style.opacity = '0';
const summary = payload.sessionSummary;
if (summary && (summary.failedAttempts > 0 || summary.tamperCount > 0)) {
const banner = document.getElementById('post-session-banner');
document.getElementById('post-session-title').textContent =
`⚠️ ${summary.tamperCount} Tamper / Unlock Attempt(s) Recorded While You Were Away`;
document.getElementById('post-session-desc').textContent =
`Session duration: ${formatDuration(summary.durationSec)} • Failed password tries: ${summary.failedAttempts}`;
banner.classList.remove('hidden');
}
bridge.getTamperLogs().then((logs) => {
appState.tamperLogs = logs;
renderTamperLogs(logs);
});
}
function updateLockTamperBadge(count) {
const warnEl = document.getElementById('lock-tamper-warning');
const textEl = document.getElementById('lock-tamper-count-text');
if (count > 0) {
textEl.textContent = `${count} unauthorized unlock or shortcut attempt(s) logged`;
warnEl.classList.remove('hidden');
}
}
function formatDuration(totalSec) {
const h = Math.floor(totalSec / 3600);
const m = Math.floor((totalSec % 3600) / 60);
const s = totalSec % 60;
return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
}
function startLockTimers() {
stopLockTimers();
const updateClockAndElapsed = () => {
const now = new Date();
document.getElementById('lock-clock-pill').textContent = now.toLocaleTimeString([], {
hour: '2-digit',
minute: '2-digit'
});
const elapsedSec = Math.max(
0,
Math.floor((Date.now() - (appState.lockStartedAt || Date.now())) / 1000)
);
document.getElementById('lock-elapsed-timer').textContent = `Away: ${formatDuration(elapsedSec)}`;
};
updateClockAndElapsed();
awayClockInterval = setInterval(updateClockAndElapsed, 1000);
}
function stopLockTimers() {
if (awayClockInterval) {
clearInterval(awayClockInterval);
awayClockInterval = null;
}
}
function startOrStopDecoyAnimations() {
if (decoyStreamInterval) {
clearInterval(decoyStreamInterval);
decoyStreamInterval = null;
}
if (!appState.isLocked) return;
const theme = appState.config.overlayTheme;
if (theme === 'decoy-update') {
let pct = 34;
const fillEl = document.getElementById('decoy-progress-fill');
if (fillEl) fillEl.style.width = `${pct}%`;
decoyStreamInterval = setInterval(() => {
pct = pct >= 94 ? 34 : pct + 1;
if (fillEl) fillEl.style.width = `${pct}%`;
}, 4500);
} else if (theme === 'decoy-win-update') {
let pct = 27;
const pctEl = document.getElementById('win-decoy-percent');
if (pctEl) pctEl.textContent = String(pct);
decoyStreamInterval = setInterval(() => {
pct = pct >= 98 ? 27 : pct + 1;
if (pctEl) pctEl.textContent = String(pct);
}, 3800);
} else if (theme === 'decoy-terminal') {
const sampleLogs = [
'[MLX/Metal] Compiling flash_attn_fp16 kernel (block_size=128, head_dim=128)... OK',
'[Worker-0] KV-Cache allocation: 12.4 GB pinned unified memory active',
'[Agent-Loop] Evaluating reasoning step #42 -> token throughput: 68.4 tok/s',
'[TensorStream] AllReduce sync across 10 GPU cores • latency 0.42ms',
'[Checkpoint] Persisting LoRA adapter weights shard_004.safetensors...',
'[Scheduler] Background queue active: 3 pending inference tasks'
];
let lines = [
'GhostLock Compute Shield v1.0 — Background Neural Execution Stream',
'-------------------------------------------------------------------'
];
elDecoyTerminalOutput.textContent = lines.join('\n');
decoyStreamInterval = setInterval(() => {
const ts = new Date().toISOString().split('T')[1].slice(0, 12);
const msg = sampleLogs[Math.floor(Math.random() * sampleLogs.length)];
lines.push(`[${ts}] ${msg}`);
if (lines.length > 34) lines.shift();
elDecoyTerminalOutput.textContent = lines.join('\n');
}, 900);
}
}
function renderTelemetry(telemetry) {
if (!telemetry) return;
document.getElementById('dash-cpu-val').textContent = `${telemetry.cpuPercent}%`;
document.getElementById('dash-mem-val').textContent = `${telemetry.memPercent}%`;
const batPct = telemetry.battery ? telemetry.battery.percent : 100;
const batIcon = telemetry.battery && telemetry.battery.isCharging ? '⚡' : '🔋';
document.getElementById('dash-bat-val').textContent = `${batPct}% ${batIcon}`;
document.getElementById('lock-cpu-stat').textContent = `CPU ${telemetry.cpuPercent}%`;
document.getElementById('lock-mem-stat').textContent = `RAM ${telemetry.usedMemGb || ''}GB (${telemetry.memPercent}%)`;
document.getElementById('lock-battery-pill').textContent = `${batIcon} ${batPct}% ${
telemetry.battery?.source || ''
}`;
const workloads =
telemetry.activeWorkloads && telemetry.activeWorkloads.length > 0
? telemetry.activeWorkloads
: [{ label: 'System Idle / Background Ready', count: 1 }];
document.getElementById('dash-workload-list').innerHTML = workloads
.map((w) => `<span class="workload-chip">${escapeHtml(w.label)}</span>`)
.join('');
document.getElementById('lock-workloads-row').innerHTML = workloads
.map((w) => `<span class="workload-pill-sm">● ${escapeHtml(w.label)}</span>`)
.join('');
drawSparkline('dashboard-sparkline', telemetry.cpuHistory || [15, 20, 18]);
drawSparkline('lock-heartbeat-canvas', telemetry.cpuHistory || [15, 20, 18]);
}
function drawSparkline(canvasId, history) {
const canvas = document.getElementById(canvasId);
if (!canvas) return;
const ctx = canvas.getContext('2d');
const w = canvas.width;
const h = canvas.height;
ctx.clearRect(0, 0, w, h);
if (!history || history.length < 2) return;
const grad = ctx.createLinearGradient(0, 0, 0, h);
grad.addColorStop(0, 'rgba(56, 189, 248, 0.42)');
grad.addColorStop(1, 'rgba(56, 189, 248, 0.0)');
const stepX = w / (history.length - 1);
ctx.beginPath();
history.forEach((val, idx) => {
const x = idx * stepX;
const y = h - Math.max(4, Math.min(h - 4, (val / 100) * (h - 8)));
if (idx === 0) ctx.moveTo(x, y);
else ctx.lineTo(x, y);
});
ctx.strokeStyle = '#38bdf8';
ctx.lineWidth = 2;
ctx.stroke();
ctx.lineTo(w, h);
ctx.lineTo(0, h);
ctx.closePath();
ctx.fillStyle = grad;
ctx.fill();
}
function renderTamperLogs(tamperData) {
const listEl = document.getElementById('tamper-log-list');
const badgeEl = document.getElementById('nav-tamper-badge');
const logs = (tamperData && tamperData.historicalLogs) || [];
if (logs.length > 0) {
badgeEl.textContent = String(logs.length);
badgeEl.classList.remove('hidden');
} else {
badgeEl.classList.add('hidden');
}
if (logs.length === 0) {
listEl.innerHTML = `<div class="empty-state">No tamper or intruder events recorded yet.</div>`;
return;
}
listEl.innerHTML = logs
.slice(0, 30)
.map((item) => {
const timeStr = new Date(item.timestamp).toLocaleString();
let detailText = '';
let thumbHtml = '';
if (item.type === 'INTRUDER_PHOTO') {
detailText = `Silent webcam snapshot captured on failed password attempt #${
item.details?.attemptNumber || 1
}`;
if (item.details?.photoDataUrl && String(item.details.photoDataUrl).startsWith('data:image/')) {
thumbHtml = `<img class="tamper-photo-thumb" src="${escapeHtml(
item.details.photoDataUrl
)}" alt="Intruder Snapshot" />`;
}
} else if (item.type === 'FAILED_PASSWORD') {
detailText = `Wrong password entered (Attempt #${item.details?.attemptNumber || 1}, length ${
item.details?.inputLength || 0
})`;
} else if (item.type === 'BLOCKED_SHORTCUT') {
detailText = `Blocked bypass shortcut: ${item.details?.shortcut || 'Key Combo'}`;
} else if (item.type === 'EMERGENCY_OS_SLEEP') {
detailText = `Triggered Native OS Sleep / System Password Fallback`;
} else {
detailText = JSON.stringify(item.details || {});
}
return `
<div class="tamper-item">
<div class="tamper-item-left">
${thumbHtml}
<span class="tamper-type-badge">${escapeHtml(item.type)}</span>
<span>${escapeHtml(detailText)}</span>
</div>
<span class="tamper-time">${escapeHtml(timeStr)}</span>
</div>
`;
})
.join('');
}
function escapeHtml(str) {
return String(str || '')
.replace(/&/g, '&amp;')
.replace(/</g, '&lt;')
.replace(/>/g, '&gt;')
.replace(/"/g, '&quot;');
}
init();
})();
