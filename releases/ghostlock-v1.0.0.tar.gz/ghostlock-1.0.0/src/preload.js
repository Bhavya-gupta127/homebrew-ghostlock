/* GhostLock v1.0.0 — Proprietary Freeware */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('ghostlockAPI', {
getInitialState: () => ipcRenderer.invoke('ghostlock:get-initial-state'),
saveConfig: (partialConfig) => ipcRenderer.invoke('ghostlock:save-config', partialConfig),
setMasterPassword: (password, hint) =>
ipcRenderer.invoke('ghostlock:set-master-password', { password, hint }),
engageLock: (options) => ipcRenderer.invoke('ghostlock:engage-lock', options),
attemptUnlock: (password) => ipcRenderer.invoke('ghostlock:attempt-unlock', password),
triggerEmergencyOsSleep: () => ipcRenderer.invoke('ghostlock:emergency-os-sleep'),
getTelemetry: () => ipcRenderer.invoke('ghostlock:get-telemetry'),
getTamperLogs: () => ipcRenderer.invoke('ghostlock:get-tamper-logs'),
clearTamperLogs: () => ipcRenderer.invoke('ghostlock:clear-tamper-logs'),
recordTamperEvent: (type, details) =>
ipcRenderer.invoke('ghostlock:record-tamper', { type, details }),
minimizeWindow: () => ipcRenderer.invoke('ghostlock:window-minimize'),
closeWindow: () => ipcRenderer.invoke('ghostlock:window-close'),
onLockStateChanged: (callback) => {
const listener = (_event, payload) => callback(payload);
ipcRenderer.on('ghostlock:lock-state-changed', listener);
return () => ipcRenderer.removeListener('ghostlock:lock-state-changed', listener);
},
onTelemetryUpdate: (callback) => {
const listener = (_event, payload) => callback(payload);
ipcRenderer.on('ghostlock:telemetry-update', listener);
return () => ipcRenderer.removeListener('ghostlock:telemetry-update', listener);
},
onTamperRecorded: (callback) => {
const listener = (_event, payload) => callback(payload);
ipcRenderer.on('ghostlock:tamper-recorded', listener);
return () => ipcRenderer.removeListener('ghostlock:tamper-recorded', listener);
}
});
