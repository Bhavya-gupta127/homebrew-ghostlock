#!/usr/bin/env bash
# ============================================================================
# GhostLock — Zero-Quarantine Office MacBook Local Builder
# ============================================================================
# Why local compilation works on corporate/MDM MacBooks:
# 1. Downloaded binaries from browsers receive the `com.apple.quarantine` xattr,
#    causing Gatekeeper to block unsigned apps.
# 2. Compiling locally with Xcode Command Line Tools (`swiftc`) in ~/ user space
#    produces a clean local binary with NO quarantine attribute and signs it
#    with an ad-hoc local Mach-O signature (`codesign -s -`).
# 3. Requires ZERO root/sudo privileges and installs cleanly in user directory.
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="$ROOT_DIR/build/GhostLockNative.app"
MACOS_DIR="$BUILD_DIR/Contents/MacOS"
RESOURCES_DIR="$BUILD_DIR/Contents/Resources"

echo "🔒 Building GhostLock Native macOS Kiosk Helper & App Bundle..."

if ! command -v swiftc >/dev/null 2>&1; then
  echo "⚠️  swiftc not found. Install Xcode Command Line Tools with: xcode-select --install"
  exit 1
fi

mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

cat > "$BUILD_DIR/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleExecutable</key>
  <string>GhostLockKiosk</string>
  <key>CFBundleIdentifier</key>
  <string>com.ghostlock.kiosk</string>
  <key>CFBundleName</key>
  <string>GhostLock</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleShortVersionString</key>
  <string>1.0.0</string>
  <key>LSMinimumSystemVersion</key>
  <string>12.0</string>
  <key>NSHighResolutionCapable</key>
  <true/>
</dict>
</plist>
EOF

swiftc -O \
  -framework Cocoa \
  -framework IOKit \
  -framework CryptoKit \
  "$SCRIPT_DIR/GhostLockKiosk.swift" \
  -o "$MACOS_DIR/GhostLockKiosk"

# Remove any extended quarantine attributes and apply local ad-hoc code signature
xattr -cr "$BUILD_DIR" 2>/dev/null || true
codesign --force --deep --sign - "$BUILD_DIR"

echo "✅ Built & ad-hoc signed: $BUILD_DIR"
echo "🚀 Run standalone native app with:"
echo "   GHOSTLOCK_PASSWORD='yourpassword' open '$BUILD_DIR'"
