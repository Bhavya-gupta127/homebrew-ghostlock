#!/usr/bin/env bash
# ============================================================================
# GhostLock — Double-Clickable macOS Kiosk Launcher (launch-mac.command)
# Equivalent to launch-kiosk.bat on Windows
# ============================================================================

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

chmod +x "$SCRIPT_DIR/bin/ghostlock" 2>/dev/null || true
exec "$SCRIPT_DIR/bin/ghostlock" kiosk
