//
//  GhostLockWebKiosk.swift
//  GhostLock — Native macOS Borderless WKWebView Kiosk Shield
//
//  Renders the full GhostLock Web UI inside a 100% borderless NSWindow (styleMask: .borderless)
//  with zero title bar, zero close/minimize traffic-light buttons, native Escape key swallowing,
//  and macOS PresentationOptions blocking Cmd+Tab, Force Quit, Dock, and Menu Bar while locked.
//

import Cocoa
import WebKit
import CoreGraphics

final class GhostLockApplication: NSApplication {
    var isScreenLocked: Bool = false

    override func sendEvent(_ event: NSEvent) {
        if isScreenLocked {
            if event.type == .keyDown || event.type == .keyUp || event.type == .flagsChanged {
                // Block Escape key (keyCode 53) completely while locked so holding Escape never triggers anything
                if event.keyCode == 53 {
                    return
                }
                let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
                if flags.contains(.command) || flags.contains(.control) {
                    let chars = (event.charactersIgnoringModifiers ?? "").lowercased()
                    // Allow Cmd+V / Cmd+A / Cmd+Backspace inside password field, block window/app escape shortcuts
                    if ["q", "w", "h", "m", "f", "n", "t", "r", "\t"].contains(chars) || event.keyCode == 48 {
                        return
                    }
                }
            }
        }
        super.sendEvent(event)
    }
}

final class BorderlessKioskWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

final class GhostLockWebKioskDelegate: NSObject, NSApplicationDelegate, WKUIDelegate, WKNavigationDelegate {
    private var primaryWindow: BorderlessKioskWindow?
    private var secondaryWindows: [BorderlessKioskWindow] = []
    private var webView: WKWebView?
    private var stateTimer: Timer?
    private let serverUrl: String
    private var currentlyLocked: Bool = false

    override init() {
        let env = ProcessInfo.processInfo.environment
        self.serverUrl = env["GHOSTLOCK_URL"] ?? "http://127.0.0.1:4789?kiosk=1&nativeShell=1"
        super.init()
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        buildWindows()
        startStatePoller()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(screensDidChange),
            name: NSApplication.didChangeScreenParametersNotification,
            object: nil
        )
        // Native macOS sleep & power-button lock notifications
        NSWorkspace.shared.notificationCenter.addObserver(
            self,
            selector: #selector(handleMacSleepOrNativeLock),
            name: NSWorkspace.willSleepNotification,
            object: nil
        )
        NSWorkspace.shared.notificationCenter.addObserver(
            self,
            selector: #selector(handleMacSleepOrNativeLock),
            name: NSWorkspace.screensDidSleepNotification,
            object: nil
        )
        DistributedNotificationCenter.default().addObserver(
            self,
            selector: #selector(handleMacSleepOrNativeLock),
            name: NSNotification.Name("com.apple.screenIsLocked"),
            object: nil
        )
    }

    @objc private func handleMacSleepOrNativeLock() {
        if currentlyLocked {
            notifyServerSleepWake()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                NSApp.presentationOptions = []
                NSApp.terminate(nil)
            }
        }
    }

    @objc private func screensDidChange() {
        guard let screen = NSScreen.main ?? NSScreen.screens.first else { return }
        let targetFrame = currentlyLocked ? screen.frame : screen.visibleFrame
        primaryWindow?.setFrame(targetFrame, display: true)
        webView?.frame = NSRect(x: 0, y: 0, width: targetFrame.width, height: targetFrame.height)
    }

    private func buildWindows() {
        guard let mainScreen = NSScreen.main ?? NSScreen.screens.first else { return }
        // Start in screen.visibleFrame (between the top macOS Menu Bar/Notch and bottom Dock)
        // so the top titlebar and bottom sidebar/controls never overlap with macOS system bars.
        let frame = mainScreen.visibleFrame

        let win = BorderlessKioskWindow(
            contentRect: frame,
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        win.isOpaque = true
        win.backgroundColor = NSColor(calibratedRed: 0.02, green: 0.03, blue: 0.06, alpha: 1.0)
        win.hasShadow = true
        win.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        win.level = .normal

        let config = WKWebViewConfiguration()
        config.preferences.setValue(true, forKey: "developerExtrasEnabled")

        let wv = WKWebView(frame: NSRect(x: 0, y: 0, width: frame.width, height: frame.height), configuration: config)
        wv.autoresizingMask = [.width, .height]
        wv.uiDelegate = self
        wv.navigationDelegate = self
        wv.setValue(false, forKey: "drawsBackground")

        win.contentView = wv
        win.makeKeyAndOrderFront(nil)
        win.makeFirstResponder(wv)
        NSApp.activate(ignoringOtherApps: true)

        if let url = URL(string: serverUrl) {
            wv.load(URLRequest(url: url))
        }

        self.primaryWindow = win
        self.webView = wv
    }

    private func isMacNativeScreenLocked() -> Bool {
        guard let dict = CGSessionCopyCurrentDictionary() as? [String: Any] else {
            return false
        }
        if let locked = dict["CGSSessionScreenIsLocked"] as? Bool, locked {
            return true
        }
        if let lockedNum = dict["CGSSessionScreenIsLocked"] as? NSNumber, lockedNum.boolValue {
            return true
        }
        return false
    }

    private func notifyServerSleepWake() {
        guard let url = URL(string: "http://127.0.0.1:4789/api/notify-sleep-wake") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = Data("{\"reason\":\"MACOS_NATIVE_SCREEN_LOCK\"}".utf8)
        URLSession.shared.dataTask(with: req).resume()
    }

    private func startStatePoller() {
        stateTimer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: true) { [weak self] _ in
            self?.pollServerState()
        }
    }

    private func pollServerState() {
        guard let url = URL(string: "http://127.0.0.1:4789/api/initial-state") else { return }
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let self = self else { return }
            if error != nil || data == nil {
                return
            }
            guard let json = try? JSONSerialization.jsonObject(with: data!) as? [String: Any] else {
                return
            }
            let locked = (json["isLocked"] as? Bool) ?? false
            let pendingWinAction = json["pendingWindowAction"] as? String

            DispatchQueue.main.async {
                if let action = pendingWinAction, !locked {
                    if action == "close" {
                        NSApp.terminate(nil)
                        return
                    } else if action == "minimize" {
                        NSApp.hide(nil)
                    }
                }
                self.applyLockPresentationState(locked: locked)
            }
        }
        task.resume()
    }

    private func applyLockPresentationState(locked: Bool) {
        if let ghostApp = NSApp as? GhostLockApplication {
            ghostApp.isScreenLocked = locked
        }

        if locked {
            // If user pressed the MacBook Power / Touch ID button to sleep/lock the Mac,
            // disengage GhostLock so the lock screen is gone when the user wakes the laptop back up.
            if isMacNativeScreenLocked() {
                notifyServerSleepWake()
                applyLockPresentationState(locked: false)
                return
            }

            let kioskOptions: NSApplication.PresentationOptions = [
                .autoHideDock,
                .autoHideMenuBar,
                .disableProcessSwitching,
                .disableForceQuit,
                .disableSessionTermination,
                .disableHideApplication
            ]
            if NSApp.presentationOptions != kioskOptions {
                NSApp.presentationOptions = kioskOptions
            }

            if let win = primaryWindow, let screen = NSScreen.main ?? NSScreen.screens.first {
                let targetLevel = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.maximumWindow)))
                if win.level != targetLevel {
                    win.level = targetLevel
                }
                if win.frame != screen.frame {
                    win.setFrame(screen.frame, display: true)
                    webView?.frame = NSRect(x: 0, y: 0, width: screen.frame.width, height: screen.frame.height)
                }
                if !NSApp.isActive {
                    NSApp.activate(ignoringOtherApps: true)
                }
                if !win.isKeyWindow {
                    win.makeKeyAndOrderFront(nil)
                }
            }
            currentlyLocked = true
        } else {
            if currentlyLocked {
                currentlyLocked = false
                NSApp.presentationOptions = []
            }
            if let win = primaryWindow, let screen = NSScreen.main ?? NSScreen.screens.first {
                if win.level != .normal {
                    win.level = .normal
                }
                if win.frame != screen.visibleFrame {
                    win.setFrame(screen.visibleFrame, display: true)
                    webView?.frame = NSRect(x: 0, y: 0, width: screen.visibleFrame.width, height: screen.visibleFrame.height)
                }
            }
        }
    }
}

let app = GhostLockApplication.shared
let delegate = GhostLockWebKioskDelegate()
app.delegate = delegate
app.run()
