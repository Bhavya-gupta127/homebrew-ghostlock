//
//  GhostLockKiosk.swift
//  GhostLock — Native macOS AppKit Kiosk Enforcer & Standalone Liquid Glass Lock App
//
//  Compiles locally on any MacBook with Xcode Command Line Tools (`swiftc`)
//  Zero external dependencies, zero quarantine attributes, no root/sudo required.
//

import Cocoa
import IOKit.pwr_mgt
import CryptoKit

final class CaffeinateAssertion {
    private var displayAssertionID: IOPMAssertionID = 0
    private var systemAssertionID: IOPMAssertionID = 0
    private(set) var isActive = false

    func enable(keepDisplayOn: Bool, reason: String = "GhostLock Background LLM Active") {
        disable()
        let cfReason = reason as CFString

        let sysResult = IOPMAssertionCreateWithName(
            kIOPMAssertionTypePreventUserIdleSystemSleep as CFString,
            IOPMAssertionLevel(kIOPMAssertionLevelOn),
            cfReason,
            &systemAssertionID
        )

        if keepDisplayOn {
            let dispResult = IOPMAssertionCreateWithName(
                kIOPMAssertionTypePreventUserIdleDisplaySleep as CFString,
                IOPMAssertionLevel(kIOPMAssertionLevelOn),
                cfReason,
                &displayAssertionID
            )
            isActive = (sysResult == kIOReturnSuccess || dispResult == kIOReturnSuccess)
        } else {
            isActive = (sysResult == kIOReturnSuccess)
        }
    }

    func disable() {
        if displayAssertionID != 0 {
            IOPMAssertionRelease(displayAssertionID)
            displayAssertionID = 0
        }
        if systemAssertionID != 0 {
            IOPMAssertionRelease(systemAssertionID)
            systemAssertionID = 0
        }
        isActive = false
    }
}

final class KioskShieldWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

final class GhostLockNativeController: NSObject, NSApplicationDelegate {
    private let caffeinate = CaffeinateAssertion()
    private var shieldWindows: [NSWindow] = []
    private var passwordField: NSSecureTextField?
    private var statusLabel: NSTextField?
    private var timerLabel: NSTextField?
    private var lockStartDate = Date()
    private var tickTimer: Timer?
    private var failedAttempts = 0

    // Configuration via CLI args or env
    private let expectedPasswordHash: String
    private let overlayMode: String // "liquid-glass" or "pitch-dark"
    private let keepDisplayOn: Bool
    private let awayBannerText: String

    override init() {
        let env = ProcessInfo.processInfo.environment
        if let rawPass = env["GHOSTLOCK_PASSWORD"], !rawPass.isEmpty {
            let digest = SHA256.hash(data: Data(rawPass.utf8))
            self.expectedPasswordHash = digest.map { String(format: "%02x", $0) }.joined()
        } else {
            // Default fallback PIN "1234" if launched standalone without env
            let digest = SHA256.hash(data: Data("1234".utf8))
            self.expectedPasswordHash = digest.map { String(format: "%02x", $0) }.joined()
        }
        self.overlayMode = env["GHOSTLOCK_THEME"] ?? "liquid-glass"
        self.keepDisplayOn = (env["GHOSTLOCK_KEEP_DISPLAY_ON"] ?? "1") != "0"
        self.awayBannerText = env["GHOSTLOCK_AWAY_MESSAGE"] ?? "Background LLM Running — Do Not Disturb"
        super.init()
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        engageKioskLock()
    }

    func engageKioskLock() {
        lockStartDate = Date()
        caffeinate.enable(keepDisplayOn: keepDisplayOn)

        // Enforce strict macOS PresentationOptions to disable Cmd+Tab, Force Quit (Cmd+Opt+Esc), Dock, and Menu Bar
        let kioskOptions: NSApplication.PresentationOptions = [
            .autoHideDock,
            .autoHideMenuBar,
            .disableProcessSwitching,
            .disableForceQuit,
            .disableSessionTermination,
            .disableHideApplication
        ]
        NSApp.presentationOptions = kioskOptions
        NSApp.activate(ignoringOtherApps: true)

        buildShieldWindowsForAllScreens()

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(screensDidChange),
            name: NSApplication.didChangeScreenParametersNotification,
            object: nil
        )

        tickTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.updateElapsedTimer()
            NSApp.activate(ignoringOtherApps: true)
        }
    }

    @objc private func screensDidChange() {
        buildShieldWindowsForAllScreens()
    }

    private func buildShieldWindowsForAllScreens() {
        shieldWindows.forEach { $0.orderOut(nil) }
        shieldWindows.removeAll()

        let screens = NSScreen.screens
        for (index, screen) in screens.enumerated() {
            let win = KioskShieldWindow(
                contentRect: screen.frame,
                styleMask: [.borderless],
                backing: .buffered,
                defer: false
            )
            win.level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.maximumWindow)))
            win.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
            win.isOpaque = false
            win.backgroundColor = .clear
            win.hasShadow = false
            win.ignoresMouseEvents = false

            if overlayMode == "pitch-dark" {
                let darkView = NSView(frame: screen.frame)
                darkView.wantsLayer = true
                darkView.layer?.backgroundColor = NSColor(calibratedRed: 0.01, green: 0.01, blue: 0.02, alpha: 0.995).cgColor
                win.contentView = darkView
            } else if overlayMode == "backdrop-blur" {
                // Deep Frosted Dark Backdrop Overlay
                let visualEffect = NSVisualEffectView(frame: screen.frame)
                visualEffect.material = .hudWindow
                visualEffect.blendingMode = .behindWindow
                visualEffect.state = .active
                visualEffect.appearance = NSAppearance(named: .vibrantDark)
                visualEffect.wantsLayer = true
                let tintLayer = CALayer()
                tintLayer.frame = screen.frame
                tintLayer.backgroundColor = NSColor(calibratedRed: 0.03, green: 0.05, blue: 0.10, alpha: 0.68).cgColor
                visualEffect.layer?.addSublayer(tintLayer)
                win.contentView = visualEffect
            } else {
                // Translucent Liquid Glass Overlay (See-through refractive glass over live macOS desktop)
                let visualEffect = NSVisualEffectView(frame: screen.frame)
                visualEffect.material = .underWindowBackground
                visualEffect.blendingMode = .behindWindow
                visualEffect.state = .active
                visualEffect.appearance = NSAppearance(named: .aqua)
                visualEffect.alphaValue = 0.88
                visualEffect.wantsLayer = true
                let specularLayer = CALayer()
                specularLayer.frame = screen.frame
                specularLayer.backgroundColor = NSColor(calibratedWhite: 1.0, alpha: 0.08).cgColor
                visualEffect.layer?.addSublayer(specularLayer)
                win.contentView = visualEffect
            }

            if index == 0, let contentView = win.contentView {
                populatePrimaryLockCard(in: contentView, frame: screen.frame)
            }

            win.makeKeyAndOrderFront(nil)
            shieldWindows.append(win)
        }

        if let first = shieldWindows.first, let field = passwordField {
            first.makeFirstResponder(field)
        }
    }

    private func populatePrimaryLockCard(in parent: NSView, frame: NSRect) {
        let cardWidth: CGFloat = 440
        let cardHeight: CGFloat = 330
        let cardRect = NSRect(
            x: (frame.width - cardWidth) / 2,
            y: (frame.height - cardHeight) / 2,
            width: cardWidth,
            height: cardHeight
        )

        let card = NSVisualEffectView(frame: cardRect)
        card.material = (overlayMode == "liquid-glass") ? .hudWindow : .popover
        card.blendingMode = .withinWindow
        card.state = .active
        card.wantsLayer = true
        card.layer?.cornerRadius = 24
        card.layer?.borderWidth = 1
        card.layer?.borderColor = NSColor.white.withAlphaComponent(overlayMode == "liquid-glass" ? 0.42 : 0.18).cgColor

        let title = NSTextField(labelWithString: "GhostLock Active")
        title.font = NSFont.systemFont(ofSize: 22, weight: .bold)
        title.textColor = .white
        title.alignment = .center
        title.frame = NSRect(x: 24, y: 268, width: cardWidth - 48, height: 30)
        card.addSubview(title)

        let awayLabel = NSTextField(labelWithString: awayBannerText)
        awayLabel.font = NSFont.systemFont(ofSize: 13, weight: .medium)
        awayLabel.textColor = NSColor(calibratedRed: 0.45, green: 0.88, blue: 0.68, alpha: 1.0)
        awayLabel.alignment = .center
        awayLabel.frame = NSRect(x: 24, y: 238, width: cardWidth - 48, height: 22)
        card.addSubview(awayLabel)

        let elapsed = NSTextField(labelWithString: "Awake & Caffeinated • 00:00:00")
        elapsed.font = NSFont.monospacedDigitSystemFont(ofSize: 12, weight: .regular)
        elapsed.textColor = NSColor.white.withAlphaComponent(0.65)
        elapsed.alignment = .center
        elapsed.frame = NSRect(x: 24, y: 210, width: cardWidth - 48, height: 20)
        card.addSubview(elapsed)
        self.timerLabel = elapsed

        let input = NSSecureTextField(frame: NSRect(x: 48, y: 150, width: cardWidth - 96, height: 38))
        input.placeholderString = "Enter GhostLock Password to Resume..."
        input.font = NSFont.systemFont(ofSize: 15)
        input.target = self
        input.action = #selector(verifyPasswordAction)
        card.addSubview(input)
        self.passwordField = input

        let status = NSTextField(labelWithString: "System sleep disabled • Background tasks running")
        status.font = NSFont.systemFont(ofSize: 12)
        status.textColor = NSColor.white.withAlphaComponent(0.6)
        status.alignment = .center
        status.frame = NSRect(x: 24, y: 112, width: cardWidth - 48, height: 20)
        card.addSubview(status)
        self.statusLabel = status

        let unlockBtn = NSButton(title: "Unlock Workstation", target: self, action: #selector(verifyPasswordAction))
        unlockBtn.bezelStyle = .rounded
        unlockBtn.frame = NSRect(x: 48, y: 66, width: cardWidth - 96, height: 34)
        card.addSubview(unlockBtn)

        let sleepBtn = NSButton(
            title: "Forgot Password? Sleep & Use macOS Password",
            target: self,
            action: #selector(fallbackToMacSleepAction)
        )
        sleepBtn.bezelStyle = .inline
        sleepBtn.isBordered = false
        sleepBtn.font = NSFont.systemFont(ofSize: 12, weight: .medium)
        sleepBtn.contentTintColor = NSColor(calibratedRed: 0.98, green: 0.68, blue: 0.32, alpha: 0.9)
        sleepBtn.frame = NSRect(x: 48, y: 24, width: cardWidth - 96, height: 24)
        card.addSubview(sleepBtn)

        parent.addSubview(card)
    }

    private func updateElapsedTimer() {
        let elapsed = Int(Date().timeIntervalSince(lockStartDate))
        let h = elapsed / 3600
        let m = (elapsed % 3600) / 60
        let s = elapsed % 60
        timerLabel?.stringValue = String(format: "Awake & Caffeinated • %02d:%02d:%02d", h, m, s)
    }

    @objc private func verifyPasswordAction() {
        guard let candidate = passwordField?.stringValue else { return }
        let digest = SHA256.hash(data: Data(candidate.utf8))
        let hashHex = digest.map { String(format: "%02x", $0) }.joined()

        if hashHex == expectedPasswordHash {
            releaseKioskAndExit(code: 0)
        } else {
            failedAttempts += 1
            passwordField?.stringValue = ""
            statusLabel?.textColor = .systemRed
            statusLabel?.stringValue = "Incorrect password (attempt #\(failedAttempts))"
            NSSound.beep()
        }
    }

    @objc private func fallbackToMacSleepAction() {
        // Trigger native macOS Lock Screen + Display Sleep BEFORE exiting kiosk mode
        let task1 = Process()
        task1.launchPath = "/usr/bin/osascript"
        task1.arguments = ["-e", "tell application \"System Events\" to keystroke \"q\" using {command down, control down}"]
        try? task1.run()

        let task2 = Process()
        task2.launchPath = "/usr/bin/pmset"
        task2.arguments = ["displaysleepnow"]
        try? task2.run()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.releaseKioskAndExit(code: 2)
        }
    }

    private func releaseKioskAndExit(code: Int32) {
        tickTimer?.invalidate()
        caffeinate.disable()
        NSApp.presentationOptions = []
        shieldWindows.forEach { $0.orderOut(nil) }
        exit(code)
    }
}

let app = NSApplication.shared
let delegate = GhostLockNativeController()
app.delegate = delegate
app.run()
