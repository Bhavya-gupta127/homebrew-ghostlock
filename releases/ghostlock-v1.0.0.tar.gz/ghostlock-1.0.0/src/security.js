/* GhostLock v1.0.0 — Proprietary Freeware */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const ITERATIONS = 100000;
const KEYLEN = 64;
const DIGEST = 'sha512';
const MAX_ATTEMPTS_BEFORE_COOLDOWN = 5;
const COOLDOWN_MS = 15000; // 15 seconds lockout after 5 wrong tries
class SecurityManager {
constructor(storageDir) {
this.storageDir = storageDir;
this.configPath = path.join(storageDir, 'ghostlock-config.json');
this.tamperLogPath = path.join(storageDir, 'ghostlock-tamper-log.json');
this.failedAttempts = 0;
this.cooldownUntil = 0;
this.currentSessionEvents = [];
this.lockStartedAt = null;
this.sessionOverrideHash = null;
this._ensureStorage();
this.config = this._loadConfig();
this.historicalLogs = this._loadTamperLogs();
}
_ensureStorage() {
if (!fs.existsSync(this.storageDir)) {
fs.mkdirSync(this.storageDir, { recursive: true });
}
}
_defaultConfig() {
return {
passwordHash: null,
passwordSalt: null,
passwordHint: '',
hotkey: process.platform === 'darwin' ? 'CommandOrControl+Shift+L' : 'CommandOrControl+Shift+L',
secondaryHotkey: 'CommandOrControl+Alt+L',
overlayTheme: 'liquid-glass', // 'liquid-glass' | 'backdrop-blur' | 'pitch-dark' | 'decoy-update' | 'decoy-terminal'
glassBlurPx: 14,
glassOpacity: 0.78,
screenBrightnessDim: 0, // 0 to 90% software dimming overlay
keepDisplayOn: true,
preventSystemSleep: true,
awayStatusPreset: 'llm-running',
awayCustomMessage: 'Background LLM / Agent Running — Please Do Not Disturb',
awayReturnMinutes: 45,
showHeartbeatWidget: true,
showAwayBanner: true,
lowBatteryGuardEnabled: true,
lowBatteryThreshold: 15, // %
autoSleepAfterMinutes: 0, // 0 = disabled, otherwise e.g. 120, 240
lockAllDisplays: true,
nativeMacKioskHelper: true,
captureWebcamOnTamper: false
};
}
_loadConfig() {
try {
if (fs.existsSync(this.configPath)) {
const raw = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
return { ...this._defaultConfig(), ...raw };
}
} catch (err) {
console.error('Failed to load config, using defaults:', err.message);
}
return this._defaultConfig();
}
saveConfig(partialConfig) {
this.config = { ...this.config, ...partialConfig };
try {
fs.writeFileSync(this.configPath, JSON.stringify(this.config, null, 2), 'utf8');
} catch (err) {
console.error('Failed to save config:', err.message);
}
return this.getSafeConfig();
}
getSafeConfig() {
const { passwordHash, passwordSalt, ...safe } = this.config;
return {
...safe,
hasPasswordSet: Boolean(passwordHash && passwordSalt)
};
}
hashPassword(plainPassword, salt = crypto.randomBytes(32).toString('hex')) {
const hash = crypto
.pbkdf2Sync(String(plainPassword), salt, ITERATIONS, KEYLEN, DIGEST)
.toString('hex');
return { hash, salt };
}
setMasterPassword(plainPassword, hint = '') {
if (!plainPassword || String(plainPassword).trim().length < 2) {
throw new Error('Password must be at least 2 characters long.');
}
const { hash, salt } = this.hashPassword(plainPassword);
this.saveConfig({
passwordHash: hash,
passwordSalt: salt,
passwordHint: String(hint || '').slice(0, 80)
});
return true;
}
setSessionOverridePassword(plainPassword) {
if (!plainPassword) {
this.sessionOverrideHash = null;
return;
}
this.sessionOverrideHash = this.hashPassword(plainPassword);
}
hasValidPasswordConfigured() {
return Boolean(
this.sessionOverrideHash ||
(this.config.passwordHash && this.config.passwordSalt)
);
}
startLockSession(sessionPassword = null) {
this.failedAttempts = 0;
this.cooldownUntil = 0;
this.currentSessionEvents = [];
this.lockStartedAt = Date.now();
if (sessionPassword && String(sessionPassword).trim().length > 0) {
this.setSessionOverridePassword(sessionPassword);
} else {
this.sessionOverrideHash = null;
}
}
verifyPassword(candidatePassword) {
const now = Date.now();
if (now < this.cooldownUntil) {
const remainingSec = Math.ceil((this.cooldownUntil - now) / 1000);
return {
valid: false,
lockedOut: true,
remainingSec,
failedAttempts: this.failedAttempts,
message: `Too many failed attempts. Wait ${remainingSec}s or use System Sleep fallback.`
};
}
const activeCreds = this.sessionOverrideHash || {
hash: this.config.passwordHash,
salt: this.config.passwordSalt
};
if (!activeCreds || !activeCreds.hash || !activeCreds.salt) {
return {
valid: false,
lockedOut: false,
failedAttempts: this.failedAttempts,
message: 'No password configured.'
};
}
const { hash: candidateHash } = this.hashPassword(
String(candidatePassword || ''),
activeCreds.salt
);
const a = Buffer.from(activeCreds.hash, 'hex');
const b = Buffer.from(candidateHash, 'hex');
const isMatch = a.length === b.length && crypto.timingSafeEqual(a, b);
if (isMatch) {
const summary = this.finishLockSession('UNLOCKED_BY_PASSWORD');
return {
valid: true,
lockedOut: false,
failedAttempts: 0,
sessionSummary: summary
};
}
this.failedAttempts += 1;
let lockedOut = false;
let remainingSec = 0;
if (this.failedAttempts % MAX_ATTEMPTS_BEFORE_COOLDOWN === 0) {
this.cooldownUntil = now + COOLDOWN_MS;
lockedOut = true;
remainingSec = Math.ceil(COOLDOWN_MS / 1000);
}
this.recordTamperEvent('FAILED_PASSWORD', {
attemptNumber: this.failedAttempts,
inputLength: String(candidatePassword || '').length,
triggeredCooldown: lockedOut
});
return {
valid: false,
lockedOut,
remainingSec,
failedAttempts: this.failedAttempts,
message: lockedOut
? `5 failed attempts! Locked for ${remainingSec}s.`
: `Incorrect password (attempt #${this.failedAttempts}).`
};
}
recordTamperEvent(type, details = {}) {
const now = Date.now();
if (type === 'INTRUDER_PHOTO' && details && details.photoDataUrl) {
const recentFail = this.historicalLogs.find(
(item) => item.type === 'FAILED_PASSWORD' && now - item.timestamp < 10000
);
if (recentFail) {
recentFail.details = {
...recentFail.details,
photoDataUrl: details.photoDataUrl
};
this._saveTamperLogs();
return recentFail;
}
}
if (type === 'BLOCKED_SHORTCUT') {
const lastEvent = this.historicalLogs[0];
if (
lastEvent &&
lastEvent.type === 'BLOCKED_SHORTCUT' &&
lastEvent.details?.shortcut === details?.shortcut &&
now - lastEvent.timestamp < 3000
) {
lastEvent.timestamp = now;
lastEvent.isoTime = new Date(now).toISOString();
lastEvent.details.repeatCount = (lastEvent.details.repeatCount || 1) + 1;
this._saveTamperLogs();
return lastEvent;
}
}
const event = {
id: crypto.randomUUID(),
type,
timestamp: now,
isoTime: new Date(now).toISOString(),
details
};
this.currentSessionEvents.push(event);
this.historicalLogs.unshift(event);
if (this.historicalLogs.length > 50) {
this.historicalLogs = this.historicalLogs.slice(0, 50);
}
this._saveTamperLogs();
return event;
}
finishLockSession(reason = 'UNLOCKED') {
const endedAt = Date.now();
const durationSec = this.lockStartedAt
? Math.round((endedAt - this.lockStartedAt) / 1000)
: 0;
const summary = {
reason,
startedAt: this.lockStartedAt,
endedAt,
durationSec,
failedAttempts: this.failedAttempts,
tamperCount: this.currentSessionEvents.length,
events: [...this.currentSessionEvents]
};
this.sessionOverrideHash = null;
this.failedAttempts = 0;
this.cooldownUntil = 0;
return summary;
}
_loadTamperLogs() {
try {
if (fs.existsSync(this.tamperLogPath)) {
const raw = JSON.parse(fs.readFileSync(this.tamperLogPath, 'utf8'));
if (Array.isArray(raw)) {
return raw.slice(0, 50);
}
}
} catch (err) {
console.error('Failed to read tamper logs:', err.message);
}
return [];
}
_saveTamperLogs() {
try {
fs.writeFileSync(
this.tamperLogPath,
JSON.stringify(this.historicalLogs, null, 2),
'utf8'
);
} catch (err) {
console.error('Failed to save tamper logs:', err.message);
}
}
getTamperLogs() {
const passwordFailureCount = this.historicalLogs.filter(
(item) => item.type === 'FAILED_PASSWORD'
).length;
return {
currentSessionEvents: this.currentSessionEvents,
historicalLogs: this.historicalLogs.slice(0, 50),
failedAttempts: this.failedAttempts,
badgeCount: passwordFailureCount > 0 ? passwordFailureCount : this.historicalLogs.length
};
}
clearTamperLogs() {
this.currentSessionEvents = [];
this.historicalLogs = [];
this._saveTamperLogs();
return true;
}
}
module.exports = { SecurityManager };
