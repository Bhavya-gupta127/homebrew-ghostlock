@echo off
title GhostLock Kiosk Launcher
echo Starting GhostLock Server and Dedicated Kiosk Window...
start /B node "%~dp0src\web-preview-server.js"
timeout /t 1 /nobreak >nul

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
  start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="http://localhost:4789?kiosk=1" --start-fullscreen --kiosk --use-fake-ui-for-media-stream --user-data-dir="%TEMP%\ghostlock-kiosk-profile"
) else (
  start "" "msedge.exe" --app="http://localhost:4789?kiosk=1" --start-fullscreen --kiosk --use-fake-ui-for-media-stream --user-data-dir="%TEMP%\ghostlock-kiosk-profile"
)
