/* GhostLock v1.0.0 — Proprietary Freeware */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { SecurityManager } = require('./security');
const { SystemMonitor } = require('./system-monitor');
const PORT = process.env.PORT || 4789;
const storageDir = path.join(os.homedir(), '.ghostlock');
const securityManager = new SecurityManager(storageDir);
const systemMonitor = new SystemMonitor();
let isLocked = false;
let pendingWindowAction = null;
const MIME_TYPES = {
'.html': 'text/html; charset=utf-8',
'.css': 'text/css; charset=utf-8',
'.js': 'application/javascript; charset=utf-8',
'.json': 'application/json; charset=utf-8',
'.svg': 'image/svg+xml'
};
function readJsonBody(req) {
return new Promise((resolve) => {
let data = '';
req.on('data', (chunk) => {
data += chunk;
});
req.on('end', () => {
try {
resolve(data ? JSON.parse(data) : {});
} catch (_) {
resolve({});
}
});
});
}
function sendJson(res, status, payload) {
res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
res.end(JSON.stringify(payload));
}
systemMonitor.captureDesktopScreenDataUrl();
const server = http.createServer(async (req, res) => {
const url = new URL(req.url, `http://localhost:${PORT}`);
if (url.pathname === '/api/initial-state' && req.method === 'GET') {
const actionToSend = !isLocked ? pendingWindowAction : null;
pendingWindowAction = null;
return sendJson(res, 200, {
isLocked,
pendingWindowAction: actionToSend,
lockStartedAt: securityManager.lockStartedAt,
config: securityManager.getSafeConfig(),
backdropDataUrl: systemMonitor.cachedDesktopDataUrl || null,
telemetry: systemMonitor.getTelemetrySnapshot(),
tamperLogs: securityManager.getTamperLogs()
});
}
if (url.pathname === '/api/telemetry' && req.method === 'GET') {
return sendJson(res, 200, {
...systemMonitor.getTelemetrySnapshot(),
isLocked,
lockStartedAt: securityManager.lockStartedAt
});
}
if (url.pathname === '/api/window-action' && req.method === 'POST') {
const body = await readJsonBody(req);
if (!isLocked && (body.action === 'close' || body.action === 'minimize')) {
pendingWindowAction = body.action;
}
return sendJson(res, 200, { ok: true });
}
if (url.pathname === '/api/kiosk-breach' && req.method === 'POST') {
const body = await readJsonBody(req);
if (isLocked) {
securityManager.recordTamperEvent('BLOCKED_SHORTCUT', {
shortcut: body.reason || 'HOLD_ESCAPE_FULLSCREEN_EXIT_BLOCKED'
});
systemMonitor.respawnKioskWindowImmediate(`http://127.0.0.1:${PORT}`);
}
return sendJson(res, 200, { ok: true, respawned: isLocked });
}
if (url.pathname === '/api/save-config' && req.method === 'POST') {
const body = await readJsonBody(req);
const updated = securityManager.saveConfig(body);
if (isLocked) {
systemMonitor.startNativeCaffeinate(updated.keepDisplayOn);
}
return sendJson(res, 200, { ok: true, config: updated });
}
if (url.pathname === '/api/set-master-password' && req.method === 'POST') {
const body = await readJsonBody(req);
try {
securityManager.setMasterPassword(body.password, body.hint);
return sendJson(res, 200, { ok: true, config: securityManager.getSafeConfig() });
} catch (err) {
return sendJson(res, 400, { ok: false, error: err.message });
}
}
if (url.pathname === '/api/engage-lock' && req.method === 'POST') {
const body = await readJsonBody(req);
if (body.configUpdates) {
securityManager.saveConfig(body.configUpdates);
}
if (body.sessionPassword && String(body.sessionPassword).trim().length >= 2) {
if (!securityManager.hasValidPasswordConfigured()) {
securityManager.setMasterPassword(String(body.sessionPassword).trim(), '');
}
securityManager.startLockSession(String(body.sessionPassword).trim());
} else if (securityManager.hasValidPasswordConfigured()) {
securityManager.startLockSession(null);
} else {
return sendJson(res, 400, {
ok: false,
error: 'Please set a permanent password on the Home screen before locking.'
});
}
isLocked = true;
pendingWindowAction = null;
const cfg = securityManager.getSafeConfig();
const backdropDataUrl =
systemMonitor.cachedDesktopDataUrl || (await systemMonitor.captureDesktopScreenDataUrl());
systemMonitor.startNativeCaffeinate(cfg.keepDisplayOn);
systemMonitor.startOsKeyboardShield((blockedKey) => {
securityManager.recordTamperEvent('BLOCKED_SHORTCUT', { shortcut: blockedKey });
});
systemMonitor.startSleepAndNativeLockWatcher((reason) => {
if (isLocked) {
isLocked = false;
securityManager.finishLockSession(reason || 'NATIVE_OS_SLEEP_WAKE');
systemMonitor.stopNativeCaffeinate();
systemMonitor.stopOsKeyboardShield();
}
});
if (body.fromGlobalShortcut) {
systemMonitor.ensureKioskWindowOpen(`http://127.0.0.1:${PORT}`);
}
return sendJson(res, 200, {
ok: true,
isLocked: true,
lockStartedAt: securityManager.lockStartedAt,
config: cfg,
backdropDataUrl,
telemetry: systemMonitor.getTelemetrySnapshot()
});
}
if (url.pathname === '/api/attempt-unlock' && req.method === 'POST') {
const body = await readJsonBody(req);
const result = securityManager.verifyPassword(body.password);
if (result.valid) {
isLocked = false;
systemMonitor.stopNativeCaffeinate();
systemMonitor.stopOsKeyboardShield();
systemMonitor.stopSleepAndNativeLockWatcher();
}
return sendJson(res, 200, result);
}
if (url.pathname === '/api/emergency-os-sleep' && req.method === 'POST') {
securityManager.recordTamperEvent('EMERGENCY_OS_SLEEP', {
note: 'Triggered Native OS Lock Screen & Sleep Fallback'
});
const summary = securityManager.finishLockSession('EMERGENCY_OS_SLEEP');
isLocked = false;
systemMonitor.stopNativeCaffeinate();
systemMonitor.stopOsKeyboardShield();
systemMonitor.stopSleepAndNativeLockWatcher();
await systemMonitor.triggerNativeOsSleepAndLock();
return sendJson(res, 200, { ok: true, summary });
}
if (url.pathname === '/api/notify-sleep-wake' && req.method === 'POST') {
if (isLocked) {
isLocked = false;
securityManager.finishLockSession('CLIENT_SLEEP_WAKE_AUTO_UNLOCK');
systemMonitor.stopNativeCaffeinate();
systemMonitor.stopOsKeyboardShield();
systemMonitor.stopSleepAndNativeLockWatcher();
}
return sendJson(res, 200, { ok: true, isLocked: false });
}
if (url.pathname === '/api/record-tamper' && req.method === 'POST') {
const body = await readJsonBody(req);
const event = securityManager.recordTamperEvent(body.type || 'TAMPER_EVENT', body.details || {});
return sendJson(res, 200, { ok: true, event });
}
if (url.pathname === '/api/tamper-logs' && req.method === 'GET') {
return sendJson(res, 200, securityManager.getTamperLogs());
}
if (url.pathname === '/api/clear-tamper-logs' && req.method === 'POST') {
securityManager.clearTamperLogs();
return sendJson(res, 200, { ok: true });
}
const rendererDir = path.join(__dirname, 'renderer');
let reqFile = url.pathname === '/' ? 'index.html' : url.pathname.replace(/^\/+/, '');
const safePath = path.normalize(path.join(rendererDir, reqFile));
if (!safePath.startsWith(rendererDir)) {
res.writeHead(403);
return res.end('Forbidden');
}
if (fs.existsSync(safePath) && fs.statSync(safePath).isFile()) {
const ext = path.extname(safePath);
res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
fs.createReadStream(safePath).pipe(res);
} else {
res.writeHead(404);
res.end('Not found');
}
});
if (require.main === module) {
server.listen(PORT, () => {
console.log(`\n🔒 GhostLock Local Server running at http://localhost:${PORT}`);
console.log(`    Zero-dependency mode for Office MacBooks & Cross-Platform preview.\n`);
});
}
module.exports = { server };
