/* GhostLock v1.0.0 — Proprietary Freeware */
const os = require('os');
const { exec, spawn } = require('child_process');
const LLM_AND_DEV_PROCESS_PATTERNS = [
{ match: /ollama/i, label: 'Ollama LLM Server', category: 'llm' },
{ match: /llama|llama-server|main/i, label: 'Llama.cpp Engine', category: 'llm' },
{ match: /vllm/i, label: 'vLLM Inference', category: 'llm' },
{ match: /mlx/i, label: 'Apple MLX Compute', category: 'llm' },
{ match: /claude/i, label: 'Claude Agent / Desktop', category: 'llm' },
{ match: /cursor/i, label: 'Cursor AI IDE', category: 'llm' },
{ match: /antigravity|agy/i, label: 'Antigravity AI Agent', category: 'llm' },
{ match: /python3?|uvicorn|gunicorn/i, label: 'Python Runtime / ML', category: 'compute' },
{ match: /node|tsx|ts-node|bun|deno/i, label: 'Node.js Worker', category: 'compute' },
{ match: /docker|com\.docker|containerd/i, label: 'Docker Container', category: 'compute' },
{ match: /swift|xcodebuild|clang/i, label: 'Swift / LLVM Build', category: 'compute' },
{ match: /cargo|rustc/i, label: 'Rust Compiler', category: 'compute' }
];
class SystemMonitor {
constructor() {
this.prevCpuInfo = os.cpus();
this.caffeinateProc = null;
this.nativeMacHelperProc = null;
this.cachedProcesses = [];
this.cachedBattery = {
hasBattery: true,
percent: 100,
isCharging: true,
source: 'AC Power'
};
this.lastProcessScan = 0;
this.lastBatteryScan = 0;
this.cpuHistory = new Array(24).fill(12);
}
_calculateCpuUsage() {
const currentCpus = os.cpus();
let idleDiff = 0;
let totalDiff = 0;
for (let i = 0; i < currentCpus.length; i++) {
const prev = this.prevCpuInfo[i] ? this.prevCpuInfo[i].times : currentCpus[i].times;
const curr = currentCpus[i].times;
const prevTotal = Object.values(prev).reduce((a, b) => a + b, 0);
const currTotal = Object.values(curr).reduce((a, b) => a + b, 0);
totalDiff += currTotal - prevTotal;
idleDiff += curr.idle - prev.idle;
}
this.prevCpuInfo = currentCpus;
if (totalDiff <= 0) return this.cpuHistory[this.cpuHistory.length - 1] || 8;
const usage = Math.max(1, Math.min(100, Math.round(((totalDiff - idleDiff) / totalDiff) * 100)));
this.cpuHistory.push(usage);
if (this.cpuHistory.length > 24) {
this.cpuHistory.shift();
}
return usage;
}
_scanProcessesAsync() {
const now = Date.now();
if (now - this.lastProcessScan < 4000) return;
this.lastProcessScan = now;
if (process.platform === 'darwin' || process.platform === 'linux') {
exec('ps -Ao comm', { timeout: 2500 }, (err, stdout) => {
if (err || !stdout) return;
this._parseProcessList(stdout.split('\n'));
});
} else if (process.platform === 'win32') {
exec('tasklist /FO CSV /NH', { timeout: 2500 }, (err, stdout) => {
if (err || !stdout) return;
const names = stdout
.split('\n')
.map((line) => {
const firstQuoteEnd = line.indexOf('",');
return firstQuoteEnd > 1 ? line.slice(1, firstQuoteEnd) : line.trim();
})
.filter(Boolean);
this._parseProcessList(names);
});
}
}
_parseProcessList(rawNames) {
const foundMap = new Map();
for (const raw of rawNames) {
const base = raw.trim().split('/').pop().split('\\').pop();
if (!base) continue;
for (const pattern of LLM_AND_DEV_PROCESS_PATTERNS) {
if (pattern.match.test(base)) {
const existing = foundMap.get(pattern.label);
if (existing) {
existing.count += 1;
} else {
foundMap.set(pattern.label, {
label: pattern.label,
category: pattern.category,
processName: base,
count: 1
});
}
break;
}
}
}
this.cachedProcesses = Array.from(foundMap.values()).slice(0, 6);
}
_scanBatteryAsync() {
const now = Date.now();
if (now - this.lastBatteryScan < 10000) return;
this.lastBatteryScan = now;
if (process.platform === 'darwin') {
exec('pmset -g batt', { timeout: 2000 }, (err, stdout) => {
if (err || !stdout) return;
const pctMatch = stdout.match(/(\d+)%/);
const isAC = stdout.includes('AC Power') || stdout.includes('charging') || stdout.includes('charged');
this.cachedBattery = {
hasBattery: Boolean(pctMatch),
percent: pctMatch ? parseInt(pctMatch[1], 10) : 100,
isCharging: isAC,
source: isAC ? 'AC Power' : 'Battery Power'
};
});
} else if (process.platform === 'win32') {
exec(
'powershell -NoProfile -Command "Get-CimInstance -ClassName Win32_Battery | Select-Object EstimatedChargeRemaining,BatteryStatus | ConvertTo-Json -Compress"',
{ timeout: 3000 },
(err, stdout) => {
if (err || !stdout || !stdout.trim()) return;
try {
const parsed = JSON.parse(stdout.trim());
const item = Array.isArray(parsed) ? parsed[0] : parsed;
if (item && typeof item.EstimatedChargeRemaining === 'number') {
const status = Number(item.BatteryStatus);
const isCharging = status === 2 || status === 3 || status === 6 || status === 7;
this.cachedBattery = {
hasBattery: true,
percent: item.EstimatedChargeRemaining,
isCharging,
source: isCharging ? 'AC Power' : 'Battery Power'
};
}
} catch (_) {
}
}
);
}
}
getTelemetrySnapshot() {
this._scanProcessesAsync();
this._scanBatteryAsync();
const cpuPercent = this._calculateCpuUsage();
const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;
const memPercent = Math.round((usedMem / totalMem) * 100);
const usedMemGb = (usedMem / (1024 ** 3)).toFixed(1);
const totalMemGb = (totalMem / (1024 ** 3)).toFixed(0);
return {
platform: process.platform,
hostname: os.hostname(),
cpuModel: os.cpus()[0]?.model || 'Apple Silicon / Multi-Core CPU',
cpuCores: os.cpus().length,
cpuPercent,
cpuHistory: [...this.cpuHistory],
memPercent,
usedMemGb,
totalMemGb,
battery: this.cachedBattery,
activeWorkloads: this.cachedProcesses,
caffeinateActive: Boolean(this.caffeinateProc),
timestamp: Date.now()
};
}
startNativeCaffeinate(keepDisplayOn = true) {
this.stopNativeCaffeinate();
if (process.platform === 'darwin') {
const flags = keepDisplayOn ? ['-d', '-i', '-s', '-u'] : ['-i', '-s', '-u'];
try {
this.caffeinateProc = spawn('caffeinate', flags, {
stdio: 'ignore',
detached: false
});
this.caffeinateProc.on('error', () => {
this.caffeinateProc = null;
});
} catch (err) {
console.error('Failed to spawn caffeinate:', err.message);
}
} else if (process.platform === 'win32') {
const flagsHex = keepDisplayOn ? '0x80000003' : '0x80000001';
const psCmd = `Add-Type -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint esFlags);' -Name PowerUtil -Namespace Win32; while($true) { [Win32.PowerUtil]::SetThreadExecutionState(${flagsHex}) | Out-Null; Start-Sleep -Seconds 30 }`;
try {
this.caffeinateProc = spawn(
'powershell.exe',
['-NoProfile', '-WindowStyle', 'Hidden', '-Command', psCmd],
{ stdio: 'ignore', windowsHide: true }
);
this.caffeinateProc.on('error', () => {
this.caffeinateProc = null;
});
} catch (_) {}
}
}
stopNativeCaffeinate() {
if (this.caffeinateProc) {
try {
this.caffeinateProc.kill();
} catch (_) {}
this.caffeinateProc = null;
}
}
startOsKeyboardShield(onBlockedKey) {
this.stopOsKeyboardShield();
if (process.platform === 'win32' && !process.env.GHOSTLOCK_DISABLE_OS_HOOK) {
const path = require('path');
const scriptPath = path.join(__dirname, '..', 'win32', 'WinKeyboardShield.ps1');
try {
this.osKeyboardShieldProc = spawn(
'powershell.exe',
['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', scriptPath],
{ stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true }
);
this.osKeyboardShieldProc.stdout.on('data', (chunk) => {
const lines = String(chunk).split(/\r?\n/);
for (const line of lines) {
if (line.startsWith('BLOCKED:') && typeof onBlockedKey === 'function') {
const keyName = line.replace('BLOCKED:', '').trim();
onBlockedKey(keyName);
}
}
});
this.osKeyboardShieldProc.on('error', () => {
this.osKeyboardShieldProc = null;
});
} catch (err) {
console.warn('Could not start Windows keyboard shield:', err.message);
}
}
}
stopOsKeyboardShield() {
if (this.osKeyboardShieldProc) {
try {
this.osKeyboardShieldProc.kill();
} catch (_) {}
this.osKeyboardShieldProc = null;
}
}
captureDesktopScreenDataUrl() {
return new Promise((resolve) => {
if (process.platform === 'win32') {
const psScript = `
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
$graphics = [System.Drawing.Graphics]::FromImage($bmp)
$graphics.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
$ms = New-Object System.IO.MemoryStream
$bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Jpeg)
$graphics.Dispose()
$bmp.Dispose()
[Convert]::ToBase64String($ms.ToArray())
`;
exec(
`powershell -NoProfile -WindowStyle Hidden -Command "${psScript.replace(/\r?\n/g, '; ')}"`,
{ maxBuffer: 15 * 1024 * 1024, timeout: 4000 },
(err, stdout) => {
if (!err && stdout && stdout.trim().length > 100) {
this.cachedDesktopDataUrl = `data:image/jpeg;base64,${stdout.trim()}`;
return resolve(this.cachedDesktopDataUrl);
}
resolve(this.cachedDesktopDataUrl || null);
}
);
} else if (process.platform === 'darwin') {
const fs = require('fs');
const path = require('path');
const tmpFile = path.join(os.tmpdir(), `ghostlock-desk-${Date.now()}.jpg`);
exec(`screencapture -x -t jpg "${tmpFile}" 2>/dev/null`, { timeout: 3000 }, (err) => {
try {
if (!err && fs.existsSync(tmpFile)) {
const b64 = fs.readFileSync(tmpFile).toString('base64');
fs.unlinkSync(tmpFile);
if (b64.length > 100) {
this.cachedDesktopDataUrl = `data:image/jpeg;base64,${b64}`;
return resolve(this.cachedDesktopDataUrl);
}
}
} catch (_) {}
resolve(this.cachedDesktopDataUrl || null);
});
} else {
resolve(this.cachedDesktopDataUrl || null);
}
});
}
triggerNativeOsSleepAndLock() {
return new Promise((resolve) => {
if (process.platform === 'darwin') {
const cmd = [
'osascript -e \'tell application "System Events" to keystroke "q" using {command down, control down}\' 2>/dev/null || true',
'/System/Library/CoreServices/Menu\\ Extras/User.menu/Contents/Resources/CGSession -suspend 2>/dev/null || true',
'pmset displaysleepnow 2>/dev/null || true'
].join(' ; ');
exec(cmd, () => resolve({ platform: 'darwin', action: 'native-lock-and-sleep' }));
} else if (process.platform === 'win32') {
exec('rundll32.exe user32.dll,LockWorkStation', () => {
resolve({ platform: 'win32', action: 'native-lock-workstation' });
});
} else {
exec('loginctl lock-session || xdg-screensaver lock', () => {
resolve({ platform: process.platform, action: 'native-lock-session' });
});
}
});
}
startSleepAndNativeLockWatcher(onSleepOrNativeLock) {
this.stopSleepAndNativeLockWatcher();
let lastTick = Date.now();
const startedAt = Date.now();
let checkingIoreg = false;
this.sleepWatcherInterval = setInterval(() => {
const now = Date.now();
const delta = now - lastTick;
lastTick = now;
if (delta > 3800) {
this.stopSleepAndNativeLockWatcher();
if (typeof onSleepOrNativeLock === 'function') {
onSleepOrNativeLock('SYSTEM_SLEEP_WAKE');
}
return;
}
if (process.platform === 'darwin' && now - startedAt > 2500 && !checkingIoreg) {
checkingIoreg = true;
exec(
'ioreg -n Root -d1 -a 2>/dev/null | grep -A 1 "CGSSessionScreenIsLocked"',
{ timeout: 1000 },
(err, stdout) => {
checkingIoreg = false;
if (!err && stdout && stdout.includes('<true/>')) {
this.stopSleepAndNativeLockWatcher();
if (typeof onSleepOrNativeLock === 'function') {
onSleepOrNativeLock('MACOS_POWER_BUTTON_NATIVE_LOCK');
}
}
}
);
}
}, 1000);
}
stopSleepAndNativeLockWatcher() {
if (this.sleepWatcherInterval) {
clearInterval(this.sleepWatcherInterval);
this.sleepWatcherInterval = null;
}
}
ensureKioskWindowOpen(url = 'http://127.0.0.1:4789') {
if (process.platform === 'darwin') {
const fs = require('fs');
const path = require('path');
const nativeWebBin = path.join(__dirname, '..', 'build', 'GhostLockWebKiosk.app', 'Contents', 'MacOS', 'GhostLockWebKiosk');
if (fs.existsSync(nativeWebBin)) {
exec(`pgrep -f "GhostLockWebKiosk" >/dev/null 2>&1 || GHOSTLOCK_URL="${url}?kiosk=1&nativeShell=1" "${nativeWebBin}" >/dev/null 2>&1 &`, () => {});
return;
}
const kioskProfile = path.join(os.homedir(), '.ghostlock', 'kiosk-chrome-profile');
const cmd = `open -na "Google Chrome" --args --user-data-dir="${kioskProfile}" --app="${url}?kiosk=1" --kiosk --start-fullscreen --no-first-run --no-default-browser-check --disable-session-crashed-bubble --disable-infobars --use-fake-ui-for-media-stream`;
exec(cmd, () => {});
}
}
respawnKioskWindowImmediate(url = 'http://127.0.0.1:4789') {
if (process.platform === 'darwin') {
const path = require('path');
const kioskProfile = path.join(os.homedir(), '.ghostlock', 'kiosk-chrome-profile');
const cmd = `pkill -9 -f "${kioskProfile}" 2>/dev/null || true; open -na "Google Chrome" --args --user-data-dir="${kioskProfile}" --app="${url}?kiosk=1" --kiosk --start-fullscreen --no-first-run --no-default-browser-check --disable-session-crashed-bubble --disable-infobars --use-fake-ui-for-media-stream`;
exec(cmd, () => {});
}
}
}
module.exports = { SystemMonitor };
